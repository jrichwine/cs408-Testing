﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Game
{
    public partial class MainMenu : Form
    {
        public MainMenu()
        {
            InitializeComponent();
        }

        private void poker_Click(object sender, EventArgs e)
        {
            BlackjackPlayer player = new BlackjackPlayer();
            Blackjack blackjack = new Blackjack();
            blackjack.Show();
        }

        private void blackjack_Click(object sender, EventArgs e)
        {
            Player player = new Player();
            Form1 poker = new Form1();
            poker.Show();
        }

        private void MainMenu_Load(object sender, EventArgs e)
        {

        }

        private void exitBtn_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }
    }
}
