﻿using System;
using System.Text;
using System.Collections;
using System.Drawing;
using System.IO;
using System.Windows.Forms;

namespace Game
{
    class BlackjackPlayer : Deck
    {
        static ArrayList playerHand = new ArrayList();
        static ArrayList dealerHand = new ArrayList();

        public BlackjackPlayer()
        {
            playerHand.Clear();
            dealerHand.Clear();
        }

        public static ArrayList getPlayerHand()
        {
            return playerHand;
        }
        public static ArrayList getDealerHand()
        {
            return dealerHand;
        }

        /****
        Clear all hands and deal two cards to both the player and dealer
        ****/
        public static void playerNewGame()
        {
            Card.setNumCards(0);
            createNewDeck();
            playerHand.Clear();
            dealerHand.Clear();
            for (int i = 0; i < 4; i++)
            {
                if (i < 2)
                {
                    playerHand.Add(deck[0]);
                    deck.RemoveAt(0);
                }
                else
                {
                    dealerHand.Add(deck[0]);
                    deck.RemoveAt(0);
                }
            }
            Console.WriteLine();
            printHands(); // For debugging purposes
            validateHand(0);
            validateHand(1);
        }

        /*****
            Invoked upon clicking "hit" on the Blackjack GUI
        *****/
        public static void playerHit()
        {
            playerHand.Add(deck[0]);
            deck.RemoveAt(0);
            printHands();
            int count = validateHand(0);
            if (count == 21)
            {
                dealerHit();
            }
        }

        /*****
            Invoked upon clicking "stand" on the Blackjack GUI
            The dealer stops drawing cards when the total reaches 17
        *****/
        public static void dealerHit()
        {
            while (validateHand(1) < 17)
            {
                dealerHand.Add(deck[0]);
                deck.RemoveAt(0);
                printHands();
            }
        }

        /****
        Checks the hand for a blackjack and bust
        @param type - 0=Player
                      1=Dealer
        ****/
        public static int validateHand(int type)
        {
            if (type == 0)
            {
                int count = 0;      // Count where ace == 1
                int countAce = 0;   // Count where ace == 11
                bool ace = false;   // bool to determine if one ace is already 11
                for (int i = 0; i < playerHand.Count; i++)
                {
                    Card c = (Card)playerHand[i];
                    switch (c.cNum)
                    {
                        case 1:
                            count += 11;
                            break;
                        case 2:
                        case 3:
                        case 4:
                        case 5:
                        case 6:
                        case 7:
                        case 8:
                        case 9:
                        case 10:
                            count += c.cNum;
                            countAce += c.cNum;
                            break;
                        case 11:
                            count += 10;
                            countAce += 10;
                            break;
                        case 12:
                            count += 10;
                            countAce += 10;
                            break;
                        case 13:
                            count += 10;
                            countAce += 10;
                            break;
                    }
                }

                Console.WriteLine("Player Counts:");
                Console.WriteLine("Count = " + count);
                Console.WriteLine("CountAce = " + countAce);

                if (countAce == 21 || count == 21)
                {
                    Console.WriteLine("BLACKJACK!!!");
                    return 21;
                }
                else if (count > 21)
                {
                    Console.WriteLine("BUST!");
                }
                //return count;
                if (countAce <= 21)
                {
                    return countAce;
                }
                else
                {
                    return count;
                }
            }
            else
            {
                int count = 0;
                int countAce = 0;
                bool ace = false;

                for (int i = 0; i < dealerHand.Count; i++)
                {
                    Card c = (Card)dealerHand[i];
                    switch (c.cNum)
                    {
                        case 1:
                            if (!ace)
                            {
                                ace = true;
                                countAce += 11;
                            }
                            else
                            {
                                countAce += c.cNum;
                            }
                            count += c.cNum;
                            break;
                        case 2:
                        case 3:
                        case 4:
                        case 5:
                        case 6:
                        case 7:
                        case 8:
                        case 9:
                        case 10:
                            count += c.cNum;
                            countAce += c.cNum;
                            break;
                        case 11:
                            count += 10;
                            countAce += 10;
                            break;
                        case 12:
                            count += 10;
                            countAce += 10;
                            break;
                        case 13:
                            count += 10;
                            countAce += 10;
                            break;
                    }
                }

                Console.WriteLine("Dealer Counts:");
                Console.WriteLine("Count = " + count);
                Console.WriteLine("CountAce = " + countAce);

                if (countAce == 21 || count == 21)
                {
                    Console.WriteLine("BLACKJACK!!!");
                    return 21;
                }
                else if (count > 21)
                {
                    Console.WriteLine("BUST!");
                    return count;
                }
                //return count;
                if (countAce <= 21)
                {
                    return countAce;
                }
                else
                {
                    return count;
                }
            }
        }

        /****
        Print player and dealer hand in the console for debugging purposes
        ****/
        public static void printHands()
        {
            Console.WriteLine("Player Hand");
            for (int i = 0; i < playerHand.Count; i++)
            {
                Card c = (Card)playerHand[i];
                Console.WriteLine("{0}:  Name: {1}  Suit: {2}", i, c.cName, c.sName);
            }
            Console.WriteLine("Dealer Hand");
            for (int i = 0; i < dealerHand.Count; i++)
            {
                Card c = (Card)dealerHand[i];
                Console.WriteLine("{0}:  Name: {1}  Suit: {2}", i, c.cName, c.sName);
            }
        }
    }

    public partial class Blackjack
    {
        protected void newGame()
        {
            BlackjackPlayer.playerNewGame();
        }

        protected void playerHit()
        {
            BlackjackPlayer.playerHit();
        }

        protected void dealerHit()
        {
            BlackjackPlayer.dealerHit();
        }

        // Update the dealer's total for just the first card the dealer is dealt
        protected void updateInitDealerTotal()
        {
            ArrayList dealerHand = BlackjackPlayer.getDealerHand();
            int count = 0;      // Count where ace == 1
            int countAce = 0;   // Count where ace == 11
            bool ace = false;   // bool to determine if one ace is already 11

            Card c = (Card)dealerHand[0];
            switch (c.cNum)
            {
                case 1:
                    if (!ace)
                    {
                        ace = true;
                        countAce += 11;
                    }
                    else
                    {
                        countAce += c.cNum;
                    }
                    count += c.cNum;
                    break;
                case 2:
                case 3:
                case 4:
                case 5:
                case 6:
                case 7:
                case 8:
                case 9:
                case 10:
                    count += c.cNum;
                    countAce += c.cNum;
                    break;
                case 11:
                    count += 10;
                    countAce += 10;
                    break;
                case 12:
                    count += 10;
                    countAce += 10;
                    break;
                case 13:
                    count += 10;
                    countAce += 10;
                    break;
            }
            dealerTotal.Text = Convert.ToString(count);
            dealerTotal.Visible = true;
            if (ace && countAce <= 21)
            {
                dealerSlash.Visible = true;
                dealerTotal2.Text = Convert.ToString(countAce);
                dealerTotal2.Visible = true;
            }
            else
            {
                dealerSlash.Visible = false;
                dealerTotal2.Visible = false;
            }
        }

        protected void updateDealerTotal()
        {
            ArrayList dealerHand = BlackjackPlayer.getDealerHand();
            int count = 0;      // Count where ace == 1
            int countAce = 0;   // Count where ace == 11
            bool ace = false;   // bool to determine if one ace is already 11
            for (int i = 0; i < dealerHand.Count; i++)
            {
                Card c = (Card)dealerHand[i];
                switch (c.cNum)
                {
                    case 1:
                        if (!ace)
                        {
                            ace = true;
                            countAce += 11;
                        }
                        else
                        {
                            countAce += c.cNum;
                        }
                        count += c.cNum;
                        break;
                    case 2:
                    case 3:
                    case 4:
                    case 5:
                    case 6:
                    case 7:
                    case 8:
                    case 9:
                    case 10:
                        count += c.cNum;
                        countAce += c.cNum;
                        break;
                    case 11:
                        count += 10;
                        countAce += 10;
                        break;
                    case 12:
                        count += 10;
                        countAce += 10;
                        break;
                    case 13:
                        count += 10;
                        countAce += 10;
                        break;
                }
            }
            dealerTotal.Text = Convert.ToString(count);
            dealerTotal.Visible = true;
            if (ace && countAce <= 21)
            {
                dealerSlash.Visible = true;
                dealerTotal2.Text = Convert.ToString(countAce);
                dealerTotal2.Visible = true;
            }
            else
            {
                dealerSlash.Visible = false;
                dealerTotal2.Visible = false;
            }

            // Check for bust and blackjack
            if (count == 21 || countAce == 21)
            {
                dealerBlackjack.Visible = true;
                hitBtn.Enabled = false;
                standBtn.Enabled = false;
                newGameBtn.Enabled = true;
            }
            else if (count > 21)
            {
                dealerBust.Visible = true;
                hitBtn.Enabled = false;
                standBtn.Enabled = false;
                newGameBtn.Enabled = true;
            }
        }

        protected void updatePlayerTotal()
        {
            ArrayList playerHand = BlackjackPlayer.getPlayerHand();
            int count = 0;      // Count where ace == 1
            int countAce = 0;   // Count where ace == 11
            bool ace = false;   // bool to determine if one ace is already 11
            for (int i = 0; i < playerHand.Count; i++)
            {
                Card c = (Card)playerHand[i];
                switch (c.cNum)
                {
                    case 1:
                        count += 11;
                        break;
                    case 2:
                    case 3:
                    case 4:
                    case 5:
                    case 6:
                    case 7:
                    case 8:
                    case 9:
                    case 10:
                        count += c.cNum;
                        countAce += c.cNum;
                        break;
                    case 11:
                        count += 10;
                        countAce += 10;
                        break;
                    case 12:
                        count += 10;
                        countAce += 10;
                        break;
                    case 13:
                        count += 10;
                        countAce += 10;
                        break;
                }
            }
            playerTotal.Text = Convert.ToString(count);
            playerTotal.Visible = true;
            if (ace && countAce <= 21)
            {
                playerSlash.Visible = true;
                playerTotal2.Text = Convert.ToString(countAce);
                playerTotal2.Visible = true;
            }
            else
            {
                playerSlash.Visible = false;
                playerTotal2.Visible = false;
            }

            // Check for bust and blackjack
            if (count == 21 || countAce == 21)
            {
                playerBlackjack.Visible = true;
                //hitBtn.Enabled = false;
                //standBtn.Enabled = false;
                //newGameBtn.Enabled = true;
                dealerHit();
                getDealerHit();
                updateDealerTotal();
                standBtn.Enabled = false;
                newGameBtn.Enabled = true;

                winAmountLabel.Visible = true;
                winAmountLabel.Text = "WIN " + (betAmount * 2);
                numCredits += betAmount * 2;
                creditLabel.Text = "CREDIT " + numCredits;
            }
            else if (count > 21)
            {
                playerBust.Visible = true;
                newGameBtn.Enabled = true;
            }
        }

        protected void getDealerHit()
        {
            ArrayList hand = BlackjackPlayer.getDealerHand();
            string path = Directory.GetCurrentDirectory();
            string newPath = Path.GetFullPath(Path.Combine(path, @"..\..\"));  //C:\\Users\\Austin Dewey\\Documents\\Visual Studio 2015\\Projects\\Game\\Game
            //string file = newPath + @"\Images\Cards\ace_clubs.png";
            string file;

            // Show turned-over card and other cards in dealer hand
            for (int i = 1; i < hand.Count; i++)
            {
                switch (i)
                {
                    case 1:
                        dealerCard2.Visible = true;
                        dealerCard2.BringToFront();
                        break;
                    case 2:
                        dealerCard3.Visible = true;
                        dealerCard3.BringToFront();
                        break;
                    case 3:
                        dealerCard4.Visible = true;
                        dealerCard4.BringToFront();
                        break;
                    case 4:
                        dealerCard5.Visible = true;
                        dealerCard5.BringToFront();
                        break;
                }

                Card c = (Card)hand[i];
                int num = c.cNum;
                int suit = c.sNum;

                switch (num)
                {
                    case 1:
                        switch (suit)
                        {
                            case 1:
                                file = newPath + @"\Images\Cards\ace_clubs.png";
                                switch (i)
                                {
                                    case 1:
                                        dealerCard2.Image = Image.FromFile(file);
                                        break;
                                    case 2:
                                        dealerCard3.Image = Image.FromFile(file);
                                        break;
                                    case 3:
                                        dealerCard4.Image = Image.FromFile(file);
                                        break;
                                    case 4:
                                        dealerCard5.Image = Image.FromFile(file);
                                        break;
                                }
                                break;
                            case 2:
                                file = newPath + @"\Images\Cards\ace_diamonds.png";
                                switch (i)
                                {
                                    case 1:
                                        dealerCard2.Image = Image.FromFile(file);
                                        break;
                                    case 2:
                                        dealerCard3.Image = Image.FromFile(file);
                                        break;
                                    case 3:
                                        dealerCard4.Image = Image.FromFile(file);
                                        break;
                                    case 4:
                                        dealerCard5.Image = Image.FromFile(file);
                                        break;
                                }
                                break;
                            case 3:
                                file = newPath + @"\Images\Cards\ace_hearts.png";
                                switch (i)
                                {
                                    case 1:
                                        dealerCard2.Image = Image.FromFile(file);
                                        break;
                                    case 2:
                                        dealerCard3.Image = Image.FromFile(file);
                                        break;
                                    case 3:
                                        dealerCard4.Image = Image.FromFile(file);
                                        break;
                                    case 4:
                                        dealerCard5.Image = Image.FromFile(file);
                                        break;
                                }
                                break;
                            case 4:
                                file = newPath + @"\Images\Cards\ace_spades.png";
                                switch (i)
                                {
                                    case 1:
                                        dealerCard2.Image = Image.FromFile(file);
                                        break;
                                    case 2:
                                        dealerCard3.Image = Image.FromFile(file);
                                        break;
                                    case 3:
                                        dealerCard4.Image = Image.FromFile(file);
                                        break;
                                    case 4:
                                        dealerCard5.Image = Image.FromFile(file);
                                        break;
                                }
                                break;
                        }
                        break;
                    case 2:
                        switch (suit)
                        {
                            case 1:
                                file = newPath + @"\Images\Cards\two_clubs.png";
                                switch (i)
                                {
                                    case 1:
                                        dealerCard2.Image = Image.FromFile(file);
                                        break;
                                    case 2:
                                        dealerCard3.Image = Image.FromFile(file);
                                        break;
                                    case 3:
                                        dealerCard4.Image = Image.FromFile(file);
                                        break;
                                    case 4:
                                        dealerCard5.Image = Image.FromFile(file);
                                        break;
                                }
                                break;
                            case 2:
                                file = newPath + @"\Images\Cards\two_diamonds.png";
                                switch (i)
                                {
                                    case 1:
                                        dealerCard2.Image = Image.FromFile(file);
                                        break;
                                    case 2:
                                        dealerCard3.Image = Image.FromFile(file);
                                        break;
                                    case 3:
                                        dealerCard4.Image = Image.FromFile(file);
                                        break;
                                    case 4:
                                        dealerCard5.Image = Image.FromFile(file);
                                        break;
                                }
                                break;
                            case 3:
                                file = newPath + @"\Images\Cards\two_hearts.png";
                                switch (i)
                                {
                                    case 1:
                                        dealerCard2.Image = Image.FromFile(file);
                                        break;
                                    case 2:
                                        dealerCard3.Image = Image.FromFile(file);
                                        break;
                                    case 3:
                                        dealerCard4.Image = Image.FromFile(file);
                                        break;
                                    case 4:
                                        dealerCard5.Image = Image.FromFile(file);
                                        break;
                                }
                                break;
                            case 4:
                                file = newPath + @"\Images\Cards\two_spades.png";
                                switch (i)
                                {
                                    case 1:
                                        dealerCard2.Image = Image.FromFile(file);
                                        break;
                                    case 2:
                                        dealerCard3.Image = Image.FromFile(file);
                                        break;
                                    case 3:
                                        dealerCard4.Image = Image.FromFile(file);
                                        break;
                                    case 4:
                                        dealerCard5.Image = Image.FromFile(file);
                                        break;
                                }
                                break;
                        }
                        break;
                    case 3:
                        switch (suit)
                        {
                            case 1:
                                file = newPath + @"\Images\Cards\three_clubs.png";
                                switch (i)
                                {
                                    case 1:
                                        dealerCard2.Image = Image.FromFile(file);
                                        break;
                                    case 2:
                                        dealerCard3.Image = Image.FromFile(file);
                                        break;
                                    case 3:
                                        dealerCard4.Image = Image.FromFile(file);
                                        break;
                                    case 4:
                                        dealerCard5.Image = Image.FromFile(file);
                                        break;
                                }
                                break;
                            case 2:
                                file = newPath + @"\Images\Cards\three_diamonds.png";
                                switch (i)
                                {
                                    case 1:
                                        dealerCard2.Image = Image.FromFile(file);
                                        break;
                                    case 2:
                                        dealerCard3.Image = Image.FromFile(file);
                                        break;
                                    case 3:
                                        dealerCard4.Image = Image.FromFile(file);
                                        break;
                                    case 4:
                                        dealerCard5.Image = Image.FromFile(file);
                                        break;
                                }
                                break;
                            case 3:
                                file = newPath + @"\Images\Cards\three_hearts.png";
                                switch (i)
                                {
                                    case 1:
                                        dealerCard2.Image = Image.FromFile(file);
                                        break;
                                    case 2:
                                        dealerCard3.Image = Image.FromFile(file);
                                        break;
                                    case 3:
                                        dealerCard4.Image = Image.FromFile(file);
                                        break;
                                    case 4:
                                        dealerCard5.Image = Image.FromFile(file);
                                        break;
                                }
                                break;
                            case 4:
                                file = newPath + @"\Images\Cards\three_spades.png";
                                switch (i)
                                {
                                    case 1:
                                        dealerCard2.Image = Image.FromFile(file);
                                        break;
                                    case 2:
                                        dealerCard3.Image = Image.FromFile(file);
                                        break;
                                    case 3:
                                        dealerCard4.Image = Image.FromFile(file);
                                        break;
                                    case 4:
                                        dealerCard5.Image = Image.FromFile(file);
                                        break;
                                }
                                break;
                        }
                        break;
                    case 4:
                        switch (suit)
                        {
                            case 1:
                                file = newPath + @"\Images\Cards\four_clubs.png";
                                switch (i)
                                {
                                    case 1:
                                        dealerCard2.Image = Image.FromFile(file);
                                        break;
                                    case 2:
                                        dealerCard3.Image = Image.FromFile(file);
                                        break;
                                    case 3:
                                        dealerCard4.Image = Image.FromFile(file);
                                        break;
                                    case 4:
                                        dealerCard5.Image = Image.FromFile(file);
                                        break;
                                }
                                break;
                            case 2:
                                file = newPath + @"\Images\Cards\four_diamonds.png";
                                switch (i)
                                {
                                    case 1:
                                        dealerCard2.Image = Image.FromFile(file);
                                        break;
                                    case 2:
                                        dealerCard3.Image = Image.FromFile(file);
                                        break;
                                    case 3:
                                        dealerCard4.Image = Image.FromFile(file);
                                        break;
                                    case 4:
                                        dealerCard5.Image = Image.FromFile(file);
                                        break;
                                }
                                break;
                            case 3:
                                file = newPath + @"\Images\Cards\four_hearts.png";
                                switch (i)
                                {
                                    case 1:
                                        dealerCard2.Image = Image.FromFile(file);
                                        break;
                                    case 2:
                                        dealerCard3.Image = Image.FromFile(file);
                                        break;
                                    case 3:
                                        dealerCard4.Image = Image.FromFile(file);
                                        break;
                                    case 4:
                                        dealerCard5.Image = Image.FromFile(file);
                                        break;
                                }
                                break;
                            case 4:
                                file = newPath + @"\Images\Cards\four_spades.png";
                                switch (i)
                                {
                                    case 1:
                                        dealerCard2.Image = Image.FromFile(file);
                                        break;
                                    case 2:
                                        dealerCard3.Image = Image.FromFile(file);
                                        break;
                                    case 3:
                                        dealerCard4.Image = Image.FromFile(file);
                                        break;
                                    case 4:
                                        dealerCard5.Image = Image.FromFile(file);
                                        break;
                                }
                                break;
                        }
                        break;
                    case 5:
                        switch (suit)
                        {
                            case 1:
                                file = newPath + @"\Images\Cards\five_clubs.png";
                                switch (i)
                                {
                                    case 1:
                                        dealerCard2.Image = Image.FromFile(file);
                                        break;
                                    case 2:
                                        dealerCard3.Image = Image.FromFile(file);
                                        break;
                                    case 3:
                                        dealerCard4.Image = Image.FromFile(file);
                                        break;
                                    case 4:
                                        dealerCard5.Image = Image.FromFile(file);
                                        break;
                                }
                                break;
                            case 2:
                                file = newPath + @"\Images\Cards\five_diamonds.png";
                                switch (i)
                                {
                                    case 1:
                                        dealerCard2.Image = Image.FromFile(file);
                                        break;
                                    case 2:
                                        dealerCard3.Image = Image.FromFile(file);
                                        break;
                                    case 3:
                                        dealerCard4.Image = Image.FromFile(file);
                                        break;
                                    case 4:
                                        dealerCard5.Image = Image.FromFile(file);
                                        break;
                                }
                                break;
                            case 3:
                                file = newPath + @"\Images\Cards\five_hearts.png";
                                switch (i)
                                {
                                    case 1:
                                        dealerCard2.Image = Image.FromFile(file);
                                        break;
                                    case 2:
                                        dealerCard3.Image = Image.FromFile(file);
                                        break;
                                    case 3:
                                        dealerCard4.Image = Image.FromFile(file);
                                        break;
                                    case 4:
                                        dealerCard5.Image = Image.FromFile(file);
                                        break;
                                }
                                break;
                            case 4:
                                file = newPath + @"\Images\Cards\five_spades.png";
                                switch (i)
                                {
                                    case 1:
                                        dealerCard2.Image = Image.FromFile(file);
                                        break;
                                    case 2:
                                        dealerCard3.Image = Image.FromFile(file);
                                        break;
                                    case 3:
                                        dealerCard4.Image = Image.FromFile(file);
                                        break;
                                    case 4:
                                        dealerCard5.Image = Image.FromFile(file);
                                        break;
                                }
                                break;
                        }
                        break;
                    case 6:
                        switch (suit)
                        {
                            case 1:
                                file = newPath + @"\Images\Cards\six_clubs.png";
                                switch (i)
                                {
                                    case 1:
                                        dealerCard2.Image = Image.FromFile(file);
                                        break;
                                    case 2:
                                        dealerCard3.Image = Image.FromFile(file);
                                        break;
                                    case 3:
                                        dealerCard4.Image = Image.FromFile(file);
                                        break;
                                    case 4:
                                        dealerCard5.Image = Image.FromFile(file);
                                        break;
                                }
                                break;
                            case 2:
                                file = newPath + @"\Images\Cards\six_diamonds.png";
                                switch (i)
                                {
                                    case 1:
                                        dealerCard2.Image = Image.FromFile(file);
                                        break;
                                    case 2:
                                        dealerCard3.Image = Image.FromFile(file);
                                        break;
                                    case 3:
                                        dealerCard4.Image = Image.FromFile(file);
                                        break;
                                    case 4:
                                        dealerCard5.Image = Image.FromFile(file);
                                        break;
                                }
                                break;
                            case 3:
                                file = newPath + @"\Images\Cards\six_hearts.png";
                                switch (i)
                                {
                                    case 1:
                                        dealerCard2.Image = Image.FromFile(file);
                                        break;
                                    case 2:
                                        dealerCard3.Image = Image.FromFile(file);
                                        break;
                                    case 3:
                                        dealerCard4.Image = Image.FromFile(file);
                                        break;
                                    case 4:
                                        dealerCard5.Image = Image.FromFile(file);
                                        break;
                                }
                                break;
                            case 4:
                                file = newPath + @"\Images\Cards\six_spades.png";
                                switch (i)
                                {
                                    case 1:
                                        dealerCard2.Image = Image.FromFile(file);
                                        break;
                                    case 2:
                                        dealerCard3.Image = Image.FromFile(file);
                                        break;
                                    case 3:
                                        dealerCard4.Image = Image.FromFile(file);
                                        break;
                                    case 4:
                                        dealerCard5.Image = Image.FromFile(file);
                                        break;
                                }
                                break;
                        }
                        break;
                    case 7:
                        switch (suit)
                        {
                            case 1:
                                file = newPath + @"\Images\Cards\seven_clubs.png";
                                switch (i)
                                {
                                    case 1:
                                        dealerCard2.Image = Image.FromFile(file);
                                        break;
                                    case 2:
                                        dealerCard3.Image = Image.FromFile(file);
                                        break;
                                    case 3:
                                        dealerCard4.Image = Image.FromFile(file);
                                        break;
                                    case 4:
                                        dealerCard5.Image = Image.FromFile(file);
                                        break;
                                }
                                break;
                            case 2:
                                file = newPath + @"\Images\Cards\seven_diamonds.png";
                                switch (i)
                                {
                                    case 1:
                                        dealerCard2.Image = Image.FromFile(file);
                                        break;
                                    case 2:
                                        dealerCard3.Image = Image.FromFile(file);
                                        break;
                                    case 3:
                                        dealerCard4.Image = Image.FromFile(file);
                                        break;
                                    case 4:
                                        dealerCard5.Image = Image.FromFile(file);
                                        break;
                                }
                                break;
                            case 3:
                                file = newPath + @"\Images\Cards\seven_hearts.png";
                                switch (i)
                                {
                                    case 1:
                                        dealerCard2.Image = Image.FromFile(file);
                                        break;
                                    case 2:
                                        dealerCard3.Image = Image.FromFile(file);
                                        break;
                                    case 3:
                                        dealerCard4.Image = Image.FromFile(file);
                                        break;
                                    case 4:
                                        dealerCard5.Image = Image.FromFile(file);
                                        break;
                                }
                                break;
                            case 4:
                                file = newPath + @"\Images\Cards\seven_spades.png";
                                switch (i)
                                {
                                    case 1:
                                        dealerCard2.Image = Image.FromFile(file);
                                        break;
                                    case 2:
                                        dealerCard3.Image = Image.FromFile(file);
                                        break;
                                    case 3:
                                        dealerCard4.Image = Image.FromFile(file);
                                        break;
                                    case 4:
                                        dealerCard5.Image = Image.FromFile(file);
                                        break;
                                }
                                break;
                        }
                        break;
                    case 8:
                        switch (suit)
                        {
                            case 1:
                                file = newPath + @"\Images\Cards\eight_clubs.png";
                                switch (i)
                                {
                                    case 1:
                                        dealerCard2.Image = Image.FromFile(file);
                                        break;
                                    case 2:
                                        dealerCard3.Image = Image.FromFile(file);
                                        break;
                                    case 3:
                                        dealerCard4.Image = Image.FromFile(file);
                                        break;
                                    case 4:
                                        dealerCard5.Image = Image.FromFile(file);
                                        break;
                                }
                                break;
                            case 2:
                                file = newPath + @"\Images\Cards\eight_diamonds.png";
                                switch (i)
                                {
                                    case 1:
                                        dealerCard2.Image = Image.FromFile(file);
                                        break;
                                    case 2:
                                        dealerCard3.Image = Image.FromFile(file);
                                        break;
                                    case 3:
                                        dealerCard4.Image = Image.FromFile(file);
                                        break;
                                    case 4:
                                        dealerCard5.Image = Image.FromFile(file);
                                        break;
                                }
                                break;
                            case 3:
                                file = newPath + @"\Images\Cards\eight_hearts.png";
                                switch (i)
                                {
                                    case 1:
                                        dealerCard2.Image = Image.FromFile(file);
                                        break;
                                    case 2:
                                        dealerCard3.Image = Image.FromFile(file);
                                        break;
                                    case 3:
                                        dealerCard4.Image = Image.FromFile(file);
                                        break;
                                    case 4:
                                        dealerCard5.Image = Image.FromFile(file);
                                        break;
                                }
                                break;
                            case 4:
                                file = newPath + @"\Images\Cards\eight_spades.png";
                                switch (i)
                                {
                                    case 1:
                                        dealerCard2.Image = Image.FromFile(file);
                                        break;
                                    case 2:
                                        dealerCard3.Image = Image.FromFile(file);
                                        break;
                                    case 3:
                                        dealerCard4.Image = Image.FromFile(file);
                                        break;
                                    case 4:
                                        dealerCard5.Image = Image.FromFile(file);
                                        break;
                                }
                                break;
                        }
                        break;
                    case 9:
                        switch (suit)
                        {
                            case 1:
                                file = newPath + @"\Images\Cards\nine_clubs.png";
                                switch (i)
                                {
                                    case 1:
                                        dealerCard2.Image = Image.FromFile(file);
                                        break;
                                    case 2:
                                        dealerCard3.Image = Image.FromFile(file);
                                        break;
                                    case 3:
                                        dealerCard4.Image = Image.FromFile(file);
                                        break;
                                    case 4:
                                        dealerCard5.Image = Image.FromFile(file);
                                        break;
                                }
                                break;
                            case 2:
                                file = newPath + @"\Images\Cards\nine_diamonds.png";
                                switch (i)
                                {
                                    case 1:
                                        dealerCard2.Image = Image.FromFile(file);
                                        break;
                                    case 2:
                                        dealerCard3.Image = Image.FromFile(file);
                                        break;
                                    case 3:
                                        dealerCard4.Image = Image.FromFile(file);
                                        break;
                                    case 4:
                                        dealerCard5.Image = Image.FromFile(file);
                                        break;
                                }
                                break;
                            case 3:
                                file = newPath + @"\Images\Cards\nine_hearts.png";
                                switch (i)
                                {
                                    case 1:
                                        dealerCard2.Image = Image.FromFile(file);
                                        break;
                                    case 2:
                                        dealerCard3.Image = Image.FromFile(file);
                                        break;
                                    case 3:
                                        dealerCard4.Image = Image.FromFile(file);
                                        break;
                                    case 4:
                                        dealerCard5.Image = Image.FromFile(file);
                                        break;
                                }
                                break;
                            case 4:
                                file = newPath + @"\Images\Cards\nine_spades.png";
                                switch (i)
                                {
                                    case 1:
                                        dealerCard2.Image = Image.FromFile(file);
                                        break;
                                    case 2:
                                        dealerCard3.Image = Image.FromFile(file);
                                        break;
                                    case 3:
                                        dealerCard4.Image = Image.FromFile(file);
                                        break;
                                    case 4:
                                        dealerCard5.Image = Image.FromFile(file);
                                        break;
                                }
                                break;
                        }
                        break;
                    case 10:
                        switch (suit)
                        {
                            case 1:
                                file = newPath + @"\Images\Cards\ten_clubs.png";
                                switch (i)
                                {
                                    case 1:
                                        dealerCard2.Image = Image.FromFile(file);
                                        break;
                                    case 2:
                                        dealerCard3.Image = Image.FromFile(file);
                                        break;
                                    case 3:
                                        dealerCard4.Image = Image.FromFile(file);
                                        break;
                                    case 4:
                                        dealerCard5.Image = Image.FromFile(file);
                                        break;
                                }
                                break;
                            case 2:
                                file = newPath + @"\Images\Cards\ten_diamonds.png";
                                switch (i)
                                {
                                    case 1:
                                        dealerCard2.Image = Image.FromFile(file);
                                        break;
                                    case 2:
                                        dealerCard3.Image = Image.FromFile(file);
                                        break;
                                    case 3:
                                        dealerCard4.Image = Image.FromFile(file);
                                        break;
                                    case 4:
                                        dealerCard5.Image = Image.FromFile(file);
                                        break;
                                }
                                break;
                            case 3:
                                file = newPath + @"\Images\Cards\ten_hearts.png";
                                switch (i)
                                {
                                    case 1:
                                        dealerCard2.Image = Image.FromFile(file);
                                        break;
                                    case 2:
                                        dealerCard3.Image = Image.FromFile(file);
                                        break;
                                    case 3:
                                        dealerCard4.Image = Image.FromFile(file);
                                        break;
                                    case 4:
                                        dealerCard5.Image = Image.FromFile(file);
                                        break;
                                }
                                break;
                            case 4:
                                file = newPath + @"\Images\Cards\ten_spades.png";
                                switch (i)
                                {
                                    case 1:
                                        dealerCard2.Image = Image.FromFile(file);
                                        break;
                                    case 2:
                                        dealerCard3.Image = Image.FromFile(file);
                                        break;
                                    case 3:
                                        dealerCard4.Image = Image.FromFile(file);
                                        break;
                                    case 4:
                                        dealerCard5.Image = Image.FromFile(file);
                                        break;
                                }
                                break;
                        }
                        break;
                    case 11:
                        switch (suit)
                        {
                            case 1:
                                file = newPath + @"\Images\Cards\jack_clubs.png";
                                switch (i)
                                {
                                    case 1:
                                        dealerCard2.Image = Image.FromFile(file);
                                        break;
                                    case 2:
                                        dealerCard3.Image = Image.FromFile(file);
                                        break;
                                    case 3:
                                        dealerCard4.Image = Image.FromFile(file);
                                        break;
                                    case 4:
                                        dealerCard5.Image = Image.FromFile(file);
                                        break;
                                }
                                break;
                            case 2:
                                file = newPath + @"\Images\Cards\jack_diamonds.png";
                                switch (i)
                                {
                                    case 1:
                                        dealerCard2.Image = Image.FromFile(file);
                                        break;
                                    case 2:
                                        dealerCard3.Image = Image.FromFile(file);
                                        break;
                                    case 3:
                                        dealerCard4.Image = Image.FromFile(file);
                                        break;
                                    case 4:
                                        dealerCard5.Image = Image.FromFile(file);
                                        break;
                                }
                                break;
                            case 3:
                                file = newPath + @"\Images\Cards\jack_hearts.png";
                                switch (i)
                                {
                                    case 1:
                                        dealerCard2.Image = Image.FromFile(file);
                                        break;
                                    case 2:
                                        dealerCard3.Image = Image.FromFile(file);
                                        break;
                                    case 3:
                                        dealerCard4.Image = Image.FromFile(file);
                                        break;
                                    case 4:
                                        dealerCard5.Image = Image.FromFile(file);
                                        break;
                                }
                                break;
                            case 4:
                                file = newPath + @"\Images\Cards\jack_spades.png";
                                switch (i)
                                {
                                    case 1:
                                        dealerCard2.Image = Image.FromFile(file);
                                        break;
                                    case 2:
                                        dealerCard3.Image = Image.FromFile(file);
                                        break;
                                    case 3:
                                        dealerCard4.Image = Image.FromFile(file);
                                        break;
                                    case 4:
                                        dealerCard5.Image = Image.FromFile(file);
                                        break;
                                }
                                break;
                        }
                        break;
                    case 12:
                        switch (suit)
                        {
                            case 1:
                                file = newPath + @"\Images\Cards\queen_clubs.png";
                                switch (i)
                                {
                                    case 1:
                                        dealerCard2.Image = Image.FromFile(file);
                                        break;
                                    case 2:
                                        dealerCard3.Image = Image.FromFile(file);
                                        break;
                                    case 3:
                                        dealerCard4.Image = Image.FromFile(file);
                                        break;
                                    case 4:
                                        dealerCard5.Image = Image.FromFile(file);
                                        break;
                                }
                                break;
                            case 2:
                                file = newPath + @"\Images\Cards\queen_diamonds.png";
                                switch (i)
                                {
                                    case 1:
                                        dealerCard2.Image = Image.FromFile(file);
                                        break;
                                    case 2:
                                        dealerCard3.Image = Image.FromFile(file);
                                        break;
                                    case 3:
                                        dealerCard4.Image = Image.FromFile(file);
                                        break;
                                    case 4:
                                        dealerCard5.Image = Image.FromFile(file);
                                        break;
                                }
                                break;
                            case 3:
                                file = newPath + @"\Images\Cards\queen_hearts.png";
                                switch (i)
                                {
                                    case 1:
                                        dealerCard2.Image = Image.FromFile(file);
                                        break;
                                    case 2:
                                        dealerCard3.Image = Image.FromFile(file);
                                        break;
                                    case 3:
                                        dealerCard4.Image = Image.FromFile(file);
                                        break;
                                    case 4:
                                        dealerCard5.Image = Image.FromFile(file);
                                        break;
                                }
                                break;
                            case 4:
                                file = newPath + @"\Images\Cards\queen_spades.png";
                                switch (i)
                                {
                                    case 1:
                                        dealerCard2.Image = Image.FromFile(file);
                                        break;
                                    case 2:
                                        dealerCard3.Image = Image.FromFile(file);
                                        break;
                                    case 3:
                                        dealerCard4.Image = Image.FromFile(file);
                                        break;
                                    case 4:
                                        dealerCard5.Image = Image.FromFile(file);
                                        break;
                                }
                                break;
                        }
                        break;
                    case 13:
                        switch (suit)
                        {
                            case 1:
                                file = newPath + @"\Images\Cards\king_clubs.png";
                                switch (i)
                                {
                                    case 1:
                                        dealerCard2.Image = Image.FromFile(file);
                                        break;
                                    case 2:
                                        dealerCard3.Image = Image.FromFile(file);
                                        break;
                                    case 3:
                                        dealerCard4.Image = Image.FromFile(file);
                                        break;
                                    case 4:
                                        dealerCard5.Image = Image.FromFile(file);
                                        break;
                                }
                                break;
                            case 2:
                                file = newPath + @"\Images\Cards\king_diamonds.png";
                                switch (i)
                                {
                                    case 1:
                                        dealerCard2.Image = Image.FromFile(file);
                                        break;
                                    case 2:
                                        dealerCard3.Image = Image.FromFile(file);
                                        break;
                                    case 3:
                                        dealerCard4.Image = Image.FromFile(file);
                                        break;
                                    case 4:
                                        dealerCard5.Image = Image.FromFile(file);
                                        break;
                                }
                                break;
                            case 3:
                                file = newPath + @"\Images\Cards\king_hearts.png";
                                switch (i)
                                {
                                    case 1:
                                        dealerCard2.Image = Image.FromFile(file);
                                        break;
                                    case 2:
                                        dealerCard3.Image = Image.FromFile(file);
                                        break;
                                    case 3:
                                        dealerCard4.Image = Image.FromFile(file);
                                        break;
                                    case 4:
                                        dealerCard5.Image = Image.FromFile(file);
                                        break;
                                }
                                break;
                            case 4:
                                file = newPath + @"\Images\Cards\king_spades.png";
                                switch (i)
                                {
                                    case 1:
                                        dealerCard2.Image = Image.FromFile(file);
                                        break;
                                    case 2:
                                        dealerCard3.Image = Image.FromFile(file);
                                        break;
                                    case 3:
                                        dealerCard4.Image = Image.FromFile(file);
                                        break;
                                    case 4:
                                        dealerCard5.Image = Image.FromFile(file);
                                        break;
                                }
                                break;
                        }
                        break;
                }
            }
        }

        // Originally made to support both player and dealer
        // Now it only supports the player
        // Dealer hit is in the function getDealerHit()
        protected void getHitCard(int type)
        {
            ArrayList hand;
            if (type == 0)
            {
                hand = BlackjackPlayer.getPlayerHand();
            }
            else
            {
                hand = BlackjackPlayer.getDealerHand();
            }
            Card c = (Card)hand[hand.Count - 1];
            string path = Directory.GetCurrentDirectory();
            string newPath = Path.GetFullPath(Path.Combine(path, @"..\..\"));  //C:\\Users\\Austin Dewey\\Documents\\Visual Studio 2015\\Projects\\Game\\Game
            //string file = newPath + @"\Images\Cards\ace_clubs.png";
            string file;
            int num = c.cNum;
            int suit = c.sNum;

            switch (hand.Count)
            {
                case 3:
                    if (type == 0)
                    {
                        playerCard3.Visible = true;
                    }
                    else
                    {
                        dealerCard3.Visible = true;
                    }
                    break;
                case 4:
                    if (type == 0)
                    {
                        playerCard4.Visible = true;
                    }
                    else
                    {
                        dealerCard4.Visible = true;
                    }
                    break;
                case 5:
                    if (type == 0)
                    {
                        playerCard5.Visible = true;
                        playerCard5.BringToFront();
                    }
                    else
                    {
                        dealerCard5.Visible = true;
                    }
                    break;
            }

            switch(num)
            {
                case 1:                                                             // Ace
                    switch(suit)
                    {
                        case 1:
                            file = newPath + @"\Images\Cards\ace_clubs.png";
                            switch (hand.Count)
                            {
                                case 3:
                                    if (type == 0)
                                    {
                                        playerCard3.Image = Image.FromFile(file);
                                    }
                                    else
                                    {
                                        dealerCard3.Image = Image.FromFile(file);
                                    }
                                    break;
                                case 4:
                                    if (type == 0)
                                    {
                                        playerCard4.Image = Image.FromFile(file);
                                    }
                                    else
                                    {
                                        dealerCard4.Image = Image.FromFile(file);
                                    }
                                    break;
                                case 5:
                                    if (type == 0)
                                    {
                                        playerCard5.Image = Image.FromFile(file);
                                    }
                                    else
                                    {
                                        dealerCard5.Image = Image.FromFile(file);
                                    }
                                    break;
                            }
                            break;
                        case 2:
                            file = newPath + @"\Images\Cards\ace_diamonds.png";
                            switch (hand.Count)
                            {
                                case 3:
                                    if (type == 0)
                                    {
                                        playerCard3.Image = Image.FromFile(file);
                                    }
                                    else
                                    {
                                        dealerCard3.Image = Image.FromFile(file);
                                    }
                                    break;
                                case 4:
                                    if (type == 0)
                                    {
                                        playerCard4.Image = Image.FromFile(file);
                                    }
                                    else
                                    {
                                        dealerCard4.Image = Image.FromFile(file);
                                    }
                                    break;
                                case 5:
                                    if (type == 0)
                                    {
                                        playerCard5.Image = Image.FromFile(file);
                                    }
                                    else
                                    {
                                        dealerCard5.Image = Image.FromFile(file);
                                    }
                                    break;
                            }
                            break;
                        case 3:
                            file = newPath + @"\Images\Cards\ace_hearts.png";
                            switch (hand.Count)
                            {
                                case 3:
                                    if (type == 0)
                                    {
                                        playerCard3.Image = Image.FromFile(file);
                                    }
                                    else
                                    {
                                        dealerCard3.Image = Image.FromFile(file);
                                    }
                                    break;
                                case 4:
                                    if (type == 0)
                                    {
                                        playerCard4.Image = Image.FromFile(file);
                                    }
                                    else
                                    {
                                        dealerCard4.Image = Image.FromFile(file);
                                    }
                                    break;
                                case 5:
                                    if (type == 0)
                                    {
                                        playerCard5.Image = Image.FromFile(file);
                                    }
                                    else
                                    {
                                        dealerCard5.Image = Image.FromFile(file);
                                    }
                                    break;
                            }
                            break;
                        case 4:
                            file = newPath + @"\Images\Cards\ace_spades.png";
                            switch (hand.Count)
                            {
                                case 3:
                                    if (type == 0)
                                    {
                                        playerCard3.Image = Image.FromFile(file);
                                    }
                                    else
                                    {
                                        dealerCard3.Image = Image.FromFile(file);
                                    }
                                    break;
                                case 4:
                                    if (type == 0)
                                    {
                                        playerCard4.Image = Image.FromFile(file);
                                    }
                                    else
                                    {
                                        dealerCard4.Image = Image.FromFile(file);
                                    }
                                    break;
                                case 5:
                                    if (type == 0)
                                    {
                                        playerCard5.Image = Image.FromFile(file);
                                    }
                                    else
                                    {
                                        dealerCard5.Image = Image.FromFile(file);
                                    }
                                    break;
                            }
                            break;
                    }
                    break;
                case 2:
                    switch (suit)
                    {
                        case 1:
                            file = newPath + @"\Images\Cards\two_clubs.png";
                            switch (hand.Count)
                            {
                                case 3:
                                    if (type == 0)
                                    {
                                        playerCard3.Image = Image.FromFile(file);
                                    }
                                    else
                                    {
                                        dealerCard3.Image = Image.FromFile(file);
                                    }
                                    break;
                                case 4:
                                    if (type == 0)
                                    {
                                        playerCard4.Image = Image.FromFile(file);
                                    }
                                    else
                                    {
                                        dealerCard4.Image = Image.FromFile(file);
                                    }
                                    break;
                                case 5:
                                    if (type == 0)
                                    {
                                        playerCard5.Image = Image.FromFile(file);
                                    }
                                    else
                                    {
                                        dealerCard5.Image = Image.FromFile(file);
                                    }
                                    break;
                            }
                            break;
                        case 2:
                            file = newPath + @"\Images\Cards\two_diamonds.png";
                            switch (hand.Count)
                            {
                                case 3:
                                    if (type == 0)
                                    {
                                        playerCard3.Image = Image.FromFile(file);
                                    }
                                    else
                                    {
                                        dealerCard3.Image = Image.FromFile(file);
                                    }
                                    break;
                                case 4:
                                    if (type == 0)
                                    {
                                        playerCard4.Image = Image.FromFile(file);
                                    }
                                    else
                                    {
                                        dealerCard4.Image = Image.FromFile(file);
                                    }
                                    break;
                                case 5:
                                    if (type == 0)
                                    {
                                        playerCard5.Image = Image.FromFile(file);
                                    }
                                    else
                                    {
                                        dealerCard5.Image = Image.FromFile(file);
                                    }
                                    break;
                            }
                            break;
                        case 3:
                            file = newPath + @"\Images\Cards\two_hearts.png";
                            switch (hand.Count)
                            {
                                case 3:
                                    if (type == 0)
                                    {
                                        playerCard3.Image = Image.FromFile(file);
                                    }
                                    else
                                    {
                                        dealerCard3.Image = Image.FromFile(file);
                                    }
                                    break;
                                case 4:
                                    if (type == 0)
                                    {
                                        playerCard4.Image = Image.FromFile(file);
                                    }
                                    else
                                    {
                                        dealerCard4.Image = Image.FromFile(file);
                                    }
                                    break;
                                case 5:
                                    if (type == 0)
                                    {
                                        playerCard5.Image = Image.FromFile(file);
                                    }
                                    else
                                    {
                                        dealerCard5.Image = Image.FromFile(file);
                                    }
                                    break;
                            }
                            break;
                        case 4:
                            file = newPath + @"\Images\Cards\two_spades.png";
                            switch (hand.Count)
                            {
                                case 3:
                                    if (type == 0)
                                    {
                                        playerCard3.Image = Image.FromFile(file);
                                    }
                                    else
                                    {
                                        dealerCard3.Image = Image.FromFile(file);
                                    }
                                    break;
                                case 4:
                                    if (type == 0)
                                    {
                                        playerCard4.Image = Image.FromFile(file);
                                    }
                                    else
                                    {
                                        dealerCard4.Image = Image.FromFile(file);
                                    }
                                    break;
                                case 5:
                                    if (type == 0)
                                    {
                                        playerCard5.Image = Image.FromFile(file);
                                    }
                                    else
                                    {
                                        dealerCard5.Image = Image.FromFile(file);
                                    }
                                    break;
                            }
                            break;
                    }
                    break;
                case 3:
                    switch (suit)
                    {
                        case 1:
                            file = newPath + @"\Images\Cards\three_clubs.png";
                            switch (hand.Count)
                            {
                                case 3:
                                    if (type == 0)
                                    {
                                        playerCard3.Image = Image.FromFile(file);
                                    }
                                    else
                                    {
                                        dealerCard3.Image = Image.FromFile(file);
                                    }
                                    break;
                                case 4:
                                    if (type == 0)
                                    {
                                        playerCard4.Image = Image.FromFile(file);
                                    }
                                    else
                                    {
                                        dealerCard4.Image = Image.FromFile(file);
                                    }
                                    break;
                                case 5:
                                    if (type == 0)
                                    {
                                        playerCard5.Image = Image.FromFile(file);
                                    }
                                    else
                                    {
                                        dealerCard5.Image = Image.FromFile(file);
                                    }
                                    break;
                            }
                            break;
                        case 2:
                            file = newPath + @"\Images\Cards\three_diamonds.png";
                            switch (hand.Count)
                            {
                                case 3:
                                    if (type == 0)
                                    {
                                        playerCard3.Image = Image.FromFile(file);
                                    }
                                    else
                                    {
                                        dealerCard3.Image = Image.FromFile(file);
                                    }
                                    break;
                                case 4:
                                    if (type == 0)
                                    {
                                        playerCard4.Image = Image.FromFile(file);
                                    }
                                    else
                                    {
                                        dealerCard4.Image = Image.FromFile(file);
                                    }
                                    break;
                                case 5:
                                    if (type == 0)
                                    {
                                        playerCard5.Image = Image.FromFile(file);
                                    }
                                    else
                                    {
                                        dealerCard5.Image = Image.FromFile(file);
                                    }
                                    break;
                            }
                            break;
                        case 3:
                            file = newPath + @"\Images\Cards\three_hearts.png";
                            switch (hand.Count)
                            {
                                case 3:
                                    if (type == 0)
                                    {
                                        playerCard3.Image = Image.FromFile(file);
                                    }
                                    else
                                    {
                                        dealerCard3.Image = Image.FromFile(file);
                                    }
                                    break;
                                case 4:
                                    if (type == 0)
                                    {
                                        playerCard4.Image = Image.FromFile(file);
                                    }
                                    else
                                    {
                                        dealerCard4.Image = Image.FromFile(file);
                                    }
                                    break;
                                case 5:
                                    if (type == 0)
                                    {
                                        playerCard5.Image = Image.FromFile(file);
                                    }
                                    else
                                    {
                                        dealerCard5.Image = Image.FromFile(file);
                                    }
                                    break;
                            }
                            break;
                        case 4:
                            file = newPath + @"\Images\Cards\three_spades.png";
                            switch (hand.Count)
                            {
                                case 3:
                                    if (type == 0)
                                    {
                                        playerCard3.Image = Image.FromFile(file);
                                    }
                                    else
                                    {
                                        dealerCard3.Image = Image.FromFile(file);
                                    }
                                    break;
                                case 4:
                                    if (type == 0)
                                    {
                                        playerCard4.Image = Image.FromFile(file);
                                    }
                                    else
                                    {
                                        dealerCard4.Image = Image.FromFile(file);
                                    }
                                    break;
                                case 5:
                                    if (type == 0)
                                    {
                                        playerCard5.Image = Image.FromFile(file);
                                    }
                                    else
                                    {
                                        dealerCard5.Image = Image.FromFile(file);
                                    }
                                    break;
                            }
                            break;
                    }
                    break;
                case 4:
                    switch (suit)
                    {
                        case 1:
                            file = newPath + @"\Images\Cards\four_clubs.png";
                            switch (hand.Count)
                            {
                                case 3:
                                    if (type == 0)
                                    {
                                        playerCard3.Image = Image.FromFile(file);
                                    }
                                    else
                                    {
                                        dealerCard3.Image = Image.FromFile(file);
                                    }
                                    break;
                                case 4:
                                    if (type == 0)
                                    {
                                        playerCard4.Image = Image.FromFile(file);
                                    }
                                    else
                                    {
                                        dealerCard4.Image = Image.FromFile(file);
                                    }
                                    break;
                                case 5:
                                    if (type == 0)
                                    {
                                        playerCard5.Image = Image.FromFile(file);
                                    }
                                    else
                                    {
                                        dealerCard5.Image = Image.FromFile(file);
                                    }
                                    break;
                            }
                            break;
                        case 2:
                            file = newPath + @"\Images\Cards\four_diamonds.png";
                            switch (hand.Count)
                            {
                                case 3:
                                    if (type == 0)
                                    {
                                        playerCard3.Image = Image.FromFile(file);
                                    }
                                    else
                                    {
                                        dealerCard3.Image = Image.FromFile(file);
                                    }
                                    break;
                                case 4:
                                    if (type == 0)
                                    {
                                        playerCard4.Image = Image.FromFile(file);
                                    }
                                    else
                                    {
                                        dealerCard4.Image = Image.FromFile(file);
                                    }
                                    break;
                                case 5:
                                    if (type == 0)
                                    {
                                        playerCard5.Image = Image.FromFile(file);
                                    }
                                    else
                                    {
                                        dealerCard5.Image = Image.FromFile(file);
                                    }
                                    break;
                            }
                            break;
                        case 3:
                            file = newPath + @"\Images\Cards\four_hearts.png";
                            switch (hand.Count)
                            {
                                case 3:
                                    if (type == 0)
                                    {
                                        playerCard3.Image = Image.FromFile(file);
                                    }
                                    else
                                    {
                                        dealerCard3.Image = Image.FromFile(file);
                                    }
                                    break;
                                case 4:
                                    if (type == 0)
                                    {
                                        playerCard4.Image = Image.FromFile(file);
                                    }
                                    else
                                    {
                                        dealerCard4.Image = Image.FromFile(file);
                                    }
                                    break;
                                case 5:
                                    if (type == 0)
                                    {
                                        playerCard5.Image = Image.FromFile(file);
                                    }
                                    else
                                    {
                                        dealerCard5.Image = Image.FromFile(file);
                                    }
                                    break;
                            }
                            break;
                        case 4:
                            file = newPath + @"\Images\Cards\four_spades.png";
                            switch (hand.Count)
                            {
                                case 3:
                                    if (type == 0)
                                    {
                                        playerCard3.Image = Image.FromFile(file);
                                    }
                                    else
                                    {
                                        dealerCard3.Image = Image.FromFile(file);
                                    }
                                    break;
                                case 4:
                                    if (type == 0)
                                    {
                                        playerCard4.Image = Image.FromFile(file);
                                    }
                                    else
                                    {
                                        dealerCard4.Image = Image.FromFile(file);
                                    }
                                    break;
                                case 5:
                                    if (type == 0)
                                    {
                                        playerCard5.Image = Image.FromFile(file);
                                    }
                                    else
                                    {
                                        dealerCard5.Image = Image.FromFile(file);
                                    }
                                    break;
                            }
                            break;
                    }
                    break;
                case 5:
                    switch (suit)
                    {
                        case 1:
                            file = newPath + @"\Images\Cards\five_clubs.png";
                            switch (hand.Count)
                            {
                                case 3:
                                    if (type == 0)
                                    {
                                        playerCard3.Image = Image.FromFile(file);
                                    }
                                    else
                                    {
                                        dealerCard3.Image = Image.FromFile(file);
                                    }
                                    break;
                                case 4:
                                    if (type == 0)
                                    {
                                        playerCard4.Image = Image.FromFile(file);
                                    }
                                    else
                                    {
                                        dealerCard4.Image = Image.FromFile(file);
                                    }
                                    break;
                                case 5:
                                    if (type == 0)
                                    {
                                        playerCard5.Image = Image.FromFile(file);
                                    }
                                    else
                                    {
                                        dealerCard5.Image = Image.FromFile(file);
                                    }
                                    break;
                            }
                            break;
                        case 2:
                            file = newPath + @"\Images\Cards\five_diamonds.png";
                            switch (hand.Count)
                            {
                                case 3:
                                    if (type == 0)
                                    {
                                        playerCard3.Image = Image.FromFile(file);
                                    }
                                    else
                                    {
                                        dealerCard3.Image = Image.FromFile(file);
                                    }
                                    break;
                                case 4:
                                    if (type == 0)
                                    {
                                        playerCard4.Image = Image.FromFile(file);
                                    }
                                    else
                                    {
                                        dealerCard4.Image = Image.FromFile(file);
                                    }
                                    break;
                                case 5:
                                    if (type == 0)
                                    {
                                        playerCard5.Image = Image.FromFile(file);
                                    }
                                    else
                                    {
                                        dealerCard5.Image = Image.FromFile(file);
                                    }
                                    break;
                            }
                            break;
                        case 3:
                            file = newPath + @"\Images\Cards\five_hearts.png";
                            switch (hand.Count)
                            {
                                case 3:
                                    if (type == 0)
                                    {
                                        playerCard3.Image = Image.FromFile(file);
                                    }
                                    else
                                    {
                                        dealerCard3.Image = Image.FromFile(file);
                                    }
                                    break;
                                case 4:
                                    if (type == 0)
                                    {
                                        playerCard4.Image = Image.FromFile(file);
                                    }
                                    else
                                    {
                                        dealerCard4.Image = Image.FromFile(file);
                                    }
                                    break;
                                case 5:
                                    if (type == 0)
                                    {
                                        playerCard5.Image = Image.FromFile(file);
                                    }
                                    else
                                    {
                                        dealerCard5.Image = Image.FromFile(file);
                                    }
                                    break;
                            }
                            break;
                        case 4:
                            file = newPath + @"\Images\Cards\five_spades.png";
                            switch (hand.Count)
                            {
                                case 3:
                                    if (type == 0)
                                    {
                                        playerCard3.Image = Image.FromFile(file);
                                    }
                                    else
                                    {
                                        dealerCard3.Image = Image.FromFile(file);
                                    }
                                    break;
                                case 4:
                                    if (type == 0)
                                    {
                                        playerCard4.Image = Image.FromFile(file);
                                    }
                                    else
                                    {
                                        dealerCard4.Image = Image.FromFile(file);
                                    }
                                    break;
                                case 5:
                                    if (type == 0)
                                    {
                                        playerCard5.Image = Image.FromFile(file);
                                    }
                                    else
                                    {
                                        dealerCard5.Image = Image.FromFile(file);
                                    }
                                    break;
                            }
                            break;
                    }
                    break;
                case 6:
                    switch (suit)
                    {
                        case 1:
                            file = newPath + @"\Images\Cards\six_clubs.png";
                            switch (hand.Count)
                            {
                                case 3:
                                    if (type == 0)
                                    {
                                        playerCard3.Image = Image.FromFile(file);
                                    }
                                    else
                                    {
                                        dealerCard3.Image = Image.FromFile(file);
                                    }
                                    break;
                                case 4:
                                    if (type == 0)
                                    {
                                        playerCard4.Image = Image.FromFile(file);
                                    }
                                    else
                                    {
                                        dealerCard4.Image = Image.FromFile(file);
                                    }
                                    break;
                                case 5:
                                    if (type == 0)
                                    {
                                        playerCard5.Image = Image.FromFile(file);
                                    }
                                    else
                                    {
                                        dealerCard5.Image = Image.FromFile(file);
                                    }
                                    break;
                            }
                            break;
                        case 2:
                            file = newPath + @"\Images\Cards\six_diamonds.png";
                            switch (hand.Count)
                            {
                                case 3:
                                    if (type == 0)
                                    {
                                        playerCard3.Image = Image.FromFile(file);
                                    }
                                    else
                                    {
                                        dealerCard3.Image = Image.FromFile(file);
                                    }
                                    break;
                                case 4:
                                    if (type == 0)
                                    {
                                        playerCard4.Image = Image.FromFile(file);
                                    }
                                    else
                                    {
                                        dealerCard4.Image = Image.FromFile(file);
                                    }
                                    break;
                                case 5:
                                    if (type == 0)
                                    {
                                        playerCard5.Image = Image.FromFile(file);
                                    }
                                    else
                                    {
                                        dealerCard5.Image = Image.FromFile(file);
                                    }
                                    break;
                            }
                            break;
                        case 3:
                            file = newPath + @"\Images\Cards\six_hearts.png";
                            switch (hand.Count)
                            {
                                case 3:
                                    if (type == 0)
                                    {
                                        playerCard3.Image = Image.FromFile(file);
                                    }
                                    else
                                    {
                                        dealerCard3.Image = Image.FromFile(file);
                                    }
                                    break;
                                case 4:
                                    if (type == 0)
                                    {
                                        playerCard4.Image = Image.FromFile(file);
                                    }
                                    else
                                    {
                                        dealerCard4.Image = Image.FromFile(file);
                                    }
                                    break;
                                case 5:
                                    if (type == 0)
                                    {
                                        playerCard5.Image = Image.FromFile(file);
                                    }
                                    else
                                    {
                                        dealerCard5.Image = Image.FromFile(file);
                                    }
                                    break;
                            }
                            break;
                        case 4:
                            file = newPath + @"\Images\Cards\six_spades.png";
                            switch (hand.Count)
                            {
                                case 3:
                                    if (type == 0)
                                    {
                                        playerCard3.Image = Image.FromFile(file);
                                    }
                                    else
                                    {
                                        dealerCard3.Image = Image.FromFile(file);
                                    }
                                    break;
                                case 4:
                                    if (type == 0)
                                    {
                                        playerCard4.Image = Image.FromFile(file);
                                    }
                                    else
                                    {
                                        dealerCard4.Image = Image.FromFile(file);
                                    }
                                    break;
                                case 5:
                                    if (type == 0)
                                    {
                                        playerCard5.Image = Image.FromFile(file);
                                    }
                                    else
                                    {
                                        dealerCard5.Image = Image.FromFile(file);
                                    }
                                    break;
                            }
                            break;
                    }
                    break;
                case 7:
                    switch (suit)
                    {
                        case 1:
                            file = newPath + @"\Images\Cards\seven_clubs.png";
                            switch (hand.Count)
                            {
                                case 3:
                                    if (type == 0)
                                    {
                                        playerCard3.Image = Image.FromFile(file);
                                    }
                                    else
                                    {
                                        dealerCard3.Image = Image.FromFile(file);
                                    }
                                    break;
                                case 4:
                                    if (type == 0)
                                    {
                                        playerCard4.Image = Image.FromFile(file);
                                    }
                                    else
                                    {
                                        dealerCard4.Image = Image.FromFile(file);
                                    }
                                    break;
                                case 5:
                                    if (type == 0)
                                    {
                                        playerCard5.Image = Image.FromFile(file);
                                    }
                                    else
                                    {
                                        dealerCard5.Image = Image.FromFile(file);
                                    }
                                    break;
                            }
                            break;
                        case 2:
                            file = newPath + @"\Images\Cards\seven_diamonds.png";
                            switch (hand.Count)
                            {
                                case 3:
                                    if (type == 0)
                                    {
                                        playerCard3.Image = Image.FromFile(file);
                                    }
                                    else
                                    {
                                        dealerCard3.Image = Image.FromFile(file);
                                    }
                                    break;
                                case 4:
                                    if (type == 0)
                                    {
                                        playerCard4.Image = Image.FromFile(file);
                                    }
                                    else
                                    {
                                        dealerCard4.Image = Image.FromFile(file);
                                    }
                                    break;
                                case 5:
                                    if (type == 0)
                                    {
                                        playerCard5.Image = Image.FromFile(file);
                                    }
                                    else
                                    {
                                        dealerCard5.Image = Image.FromFile(file);
                                    }
                                    break;
                            }
                            break;
                        case 3:
                            file = newPath + @"\Images\Cards\seven_hearts.png";
                            switch (hand.Count)
                            {
                                case 3:
                                    if (type == 0)
                                    {
                                        playerCard3.Image = Image.FromFile(file);
                                    }
                                    else
                                    {
                                        dealerCard3.Image = Image.FromFile(file);
                                    }
                                    break;
                                case 4:
                                    if (type == 0)
                                    {
                                        playerCard4.Image = Image.FromFile(file);
                                    }
                                    else
                                    {
                                        dealerCard4.Image = Image.FromFile(file);
                                    }
                                    break;
                                case 5:
                                    if (type == 0)
                                    {
                                        playerCard5.Image = Image.FromFile(file);
                                    }
                                    else
                                    {
                                        dealerCard5.Image = Image.FromFile(file);
                                    }
                                    break;
                            }
                            break;
                        case 4:
                            file = newPath + @"\Images\Cards\seven_spades.png";
                            switch (hand.Count)
                            {
                                case 3:
                                    if (type == 0)
                                    {
                                        playerCard3.Image = Image.FromFile(file);
                                    }
                                    else
                                    {
                                        dealerCard3.Image = Image.FromFile(file);
                                    }
                                    break;
                                case 4:
                                    if (type == 0)
                                    {
                                        playerCard4.Image = Image.FromFile(file);
                                    }
                                    else
                                    {
                                        dealerCard4.Image = Image.FromFile(file);
                                    }
                                    break;
                                case 5:
                                    if (type == 0)
                                    {
                                        playerCard5.Image = Image.FromFile(file);
                                    }
                                    else
                                    {
                                        dealerCard5.Image = Image.FromFile(file);
                                    }
                                    break;
                            }
                            break;
                    }
                    break;
                case 8:
                    switch (suit)
                    {
                        case 1:
                            file = newPath + @"\Images\Cards\eight_clubs.png";
                            switch (hand.Count)
                            {
                                case 3:
                                    if (type == 0)
                                    {
                                        playerCard3.Image = Image.FromFile(file);
                                    }
                                    else
                                    {
                                        dealerCard3.Image = Image.FromFile(file);
                                    }
                                    break;
                                case 4:
                                    if (type == 0)
                                    {
                                        playerCard4.Image = Image.FromFile(file);
                                    }
                                    else
                                    {
                                        dealerCard4.Image = Image.FromFile(file);
                                    }
                                    break;
                                case 5:
                                    if (type == 0)
                                    {
                                        playerCard5.Image = Image.FromFile(file);
                                    }
                                    else
                                    {
                                        dealerCard5.Image = Image.FromFile(file);
                                    }
                                    break;
                            }
                            break;
                        case 2:
                            file = newPath + @"\Images\Cards\eight_diamonds.png";
                            switch (hand.Count)
                            {
                                case 3:
                                    if (type == 0)
                                    {
                                        playerCard3.Image = Image.FromFile(file);
                                    }
                                    else
                                    {
                                        dealerCard3.Image = Image.FromFile(file);
                                    }
                                    break;
                                case 4:
                                    if (type == 0)
                                    {
                                        playerCard4.Image = Image.FromFile(file);
                                    }
                                    else
                                    {
                                        dealerCard4.Image = Image.FromFile(file);
                                    }
                                    break;
                                case 5:
                                    if (type == 0)
                                    {
                                        playerCard5.Image = Image.FromFile(file);
                                    }
                                    else
                                    {
                                        dealerCard5.Image = Image.FromFile(file);
                                    }
                                    break;
                            }
                            break;
                        case 3:
                            file = newPath + @"\Images\Cards\eight_hearts.png";
                            switch (hand.Count)
                            {
                                case 3:
                                    if (type == 0)
                                    {
                                        playerCard3.Image = Image.FromFile(file);
                                    }
                                    else
                                    {
                                        dealerCard3.Image = Image.FromFile(file);
                                    }
                                    break;
                                case 4:
                                    if (type == 0)
                                    {
                                        playerCard4.Image = Image.FromFile(file);
                                    }
                                    else
                                    {
                                        dealerCard4.Image = Image.FromFile(file);
                                    }
                                    break;
                                case 5:
                                    if (type == 0)
                                    {
                                        playerCard5.Image = Image.FromFile(file);
                                    }
                                    else
                                    {
                                        dealerCard5.Image = Image.FromFile(file);
                                    }
                                    break;
                            }
                            break;
                        case 4:
                            file = newPath + @"\Images\Cards\eight_spades.png";
                            switch (hand.Count)
                            {
                                case 3:
                                    if (type == 0)
                                    {
                                        playerCard3.Image = Image.FromFile(file);
                                    }
                                    else
                                    {
                                        dealerCard3.Image = Image.FromFile(file);
                                    }
                                    break;
                                case 4:
                                    if (type == 0)
                                    {
                                        playerCard4.Image = Image.FromFile(file);
                                    }
                                    else
                                    {
                                        dealerCard4.Image = Image.FromFile(file);
                                    }
                                    break;
                                case 5:
                                    if (type == 0)
                                    {
                                        playerCard5.Image = Image.FromFile(file);
                                    }
                                    else
                                    {
                                        dealerCard5.Image = Image.FromFile(file);
                                    }
                                    break;
                            }
                            break;
                    }
                    break;
                case 9:
                    switch (suit)
                    {
                        case 1:
                            file = newPath + @"\Images\Cards\nine_clubs.png";
                            switch (hand.Count)
                            {
                                case 3:
                                    if (type == 0)
                                    {
                                        playerCard3.Image = Image.FromFile(file);
                                    }
                                    else
                                    {
                                        dealerCard3.Image = Image.FromFile(file);
                                    }
                                    break;
                                case 4:
                                    if (type == 0)
                                    {
                                        playerCard4.Image = Image.FromFile(file);
                                    }
                                    else
                                    {
                                        dealerCard4.Image = Image.FromFile(file);
                                    }
                                    break;
                                case 5:
                                    if (type == 0)
                                    {
                                        playerCard5.Image = Image.FromFile(file);
                                    }
                                    else
                                    {
                                        dealerCard5.Image = Image.FromFile(file);
                                    }
                                    break;
                            }
                            break;
                        case 2:
                            file = newPath + @"\Images\Cards\nine_diamonds.png";
                            switch (hand.Count)
                            {
                                case 3:
                                    if (type == 0)
                                    {
                                        playerCard3.Image = Image.FromFile(file);
                                    }
                                    else
                                    {
                                        dealerCard3.Image = Image.FromFile(file);
                                    }
                                    break;
                                case 4:
                                    if (type == 0)
                                    {
                                        playerCard4.Image = Image.FromFile(file);
                                    }
                                    else
                                    {
                                        dealerCard4.Image = Image.FromFile(file);
                                    }
                                    break;
                                case 5:
                                    if (type == 0)
                                    {
                                        playerCard5.Image = Image.FromFile(file);
                                    }
                                    else
                                    {
                                        dealerCard5.Image = Image.FromFile(file);
                                    }
                                    break;
                            }
                            break;
                        case 3:
                            file = newPath + @"\Images\Cards\nine_hearts.png";
                            switch (hand.Count)
                            {
                                case 3:
                                    if (type == 0)
                                    {
                                        playerCard3.Image = Image.FromFile(file);
                                    }
                                    else
                                    {
                                        dealerCard3.Image = Image.FromFile(file);
                                    }
                                    break;
                                case 4:
                                    if (type == 0)
                                    {
                                        playerCard4.Image = Image.FromFile(file);
                                    }
                                    else
                                    {
                                        dealerCard4.Image = Image.FromFile(file);
                                    }
                                    break;
                                case 5:
                                    if (type == 0)
                                    {
                                        playerCard5.Image = Image.FromFile(file);
                                    }
                                    else
                                    {
                                        dealerCard5.Image = Image.FromFile(file);
                                    }
                                    break;
                            }
                            break;
                        case 4:
                            file = newPath + @"\Images\Cards\nine_spades.png";
                            switch (hand.Count)
                            {
                                case 3:
                                    if (type == 0)
                                    {
                                        playerCard3.Image = Image.FromFile(file);
                                    }
                                    else
                                    {
                                        dealerCard3.Image = Image.FromFile(file);
                                    }
                                    break;
                                case 4:
                                    if (type == 0)
                                    {
                                        playerCard4.Image = Image.FromFile(file);
                                    }
                                    else
                                    {
                                        dealerCard4.Image = Image.FromFile(file);
                                    }
                                    break;
                                case 5:
                                    if (type == 0)
                                    {
                                        playerCard5.Image = Image.FromFile(file);
                                    }
                                    else
                                    {
                                        dealerCard5.Image = Image.FromFile(file);
                                    }
                                    break;
                            }
                            break;
                    }
                    break;
                case 10:
                    switch (suit)
                    {
                        case 1:
                            file = newPath + @"\Images\Cards\ten_clubs.png";
                            switch (hand.Count)
                            {
                                case 3:
                                    if (type == 0)
                                    {
                                        playerCard3.Image = Image.FromFile(file);
                                    }
                                    else
                                    {
                                        dealerCard3.Image = Image.FromFile(file);
                                    }
                                    break;
                                case 4:
                                    if (type == 0)
                                    {
                                        playerCard4.Image = Image.FromFile(file);
                                    }
                                    else
                                    {
                                        dealerCard4.Image = Image.FromFile(file);
                                    }
                                    break;
                                case 5:
                                    if (type == 0)
                                    {
                                        playerCard5.Image = Image.FromFile(file);
                                    }
                                    else
                                    {
                                        dealerCard5.Image = Image.FromFile(file);
                                    }
                                    break;
                            }
                            break;
                        case 2:
                            file = newPath + @"\Images\Cards\ten_diamonds.png";
                            switch (hand.Count)
                            {
                                case 3:
                                    if (type == 0)
                                    {
                                        playerCard3.Image = Image.FromFile(file);
                                    }
                                    else
                                    {
                                        dealerCard3.Image = Image.FromFile(file);
                                    }
                                    break;
                                case 4:
                                    if (type == 0)
                                    {
                                        playerCard4.Image = Image.FromFile(file);
                                    }
                                    else
                                    {
                                        dealerCard4.Image = Image.FromFile(file);
                                    }
                                    break;
                                case 5:
                                    if (type == 0)
                                    {
                                        playerCard5.Image = Image.FromFile(file);
                                    }
                                    else
                                    {
                                        dealerCard5.Image = Image.FromFile(file);
                                    }
                                    break;
                            }
                            break;
                        case 3:
                            file = newPath + @"\Images\Cards\ten_hearts.png";
                            switch (hand.Count)
                            {
                                case 3:
                                    if (type == 0)
                                    {
                                        playerCard3.Image = Image.FromFile(file);
                                    }
                                    else
                                    {
                                        dealerCard3.Image = Image.FromFile(file);
                                    }
                                    break;
                                case 4:
                                    if (type == 0)
                                    {
                                        playerCard4.Image = Image.FromFile(file);
                                    }
                                    else
                                    {
                                        dealerCard4.Image = Image.FromFile(file);
                                    }
                                    break;
                                case 5:
                                    if (type == 0)
                                    {
                                        playerCard5.Image = Image.FromFile(file);
                                    }
                                    else
                                    {
                                        dealerCard5.Image = Image.FromFile(file);
                                    }
                                    break;
                            }
                            break;
                        case 4:
                            file = newPath + @"\Images\Cards\ten_spades.png";
                            switch (hand.Count)
                            {
                                case 3:
                                    if (type == 0)
                                    {
                                        playerCard3.Image = Image.FromFile(file);
                                    }
                                    else
                                    {
                                        dealerCard3.Image = Image.FromFile(file);
                                    }
                                    break;
                                case 4:
                                    if (type == 0)
                                    {
                                        playerCard4.Image = Image.FromFile(file);
                                    }
                                    else
                                    {
                                        dealerCard4.Image = Image.FromFile(file);
                                    }
                                    break;
                                case 5:
                                    if (type == 0)
                                    {
                                        playerCard5.Image = Image.FromFile(file);
                                    }
                                    else
                                    {
                                        dealerCard5.Image = Image.FromFile(file);
                                    }
                                    break;
                            }
                            break;
                    }
                    break;
                case 11:
                    switch (suit)
                    {
                        case 1:
                            file = newPath + @"\Images\Cards\jack_clubs.png";
                            switch (hand.Count)
                            {
                                case 3:
                                    if (type == 0)
                                    {
                                        playerCard3.Image = Image.FromFile(file);
                                    }
                                    else
                                    {
                                        dealerCard3.Image = Image.FromFile(file);
                                    }
                                    break;
                                case 4:
                                    if (type == 0)
                                    {
                                        playerCard4.Image = Image.FromFile(file);
                                    }
                                    else
                                    {
                                        dealerCard4.Image = Image.FromFile(file);
                                    }
                                    break;
                                case 5:
                                    if (type == 0)
                                    {
                                        playerCard5.Image = Image.FromFile(file);
                                    }
                                    else
                                    {
                                        dealerCard5.Image = Image.FromFile(file);
                                    }
                                    break;
                            }
                            break;
                        case 2:
                            file = newPath + @"\Images\Cards\jack_diamonds.png";
                            switch (hand.Count)
                            {
                                case 3:
                                    if (type == 0)
                                    {
                                        playerCard3.Image = Image.FromFile(file);
                                    }
                                    else
                                    {
                                        dealerCard3.Image = Image.FromFile(file);
                                    }
                                    break;
                                case 4:
                                    if (type == 0)
                                    {
                                        playerCard4.Image = Image.FromFile(file);
                                    }
                                    else
                                    {
                                        dealerCard4.Image = Image.FromFile(file);
                                    }
                                    break;
                                case 5:
                                    if (type == 0)
                                    {
                                        playerCard5.Image = Image.FromFile(file);
                                    }
                                    else
                                    {
                                        dealerCard5.Image = Image.FromFile(file);
                                    }
                                    break;
                            }
                            break;
                        case 3:
                            file = newPath + @"\Images\Cards\jack_hearts.png";
                            switch (hand.Count)
                            {
                                case 3:
                                    if (type == 0)
                                    {
                                        playerCard3.Image = Image.FromFile(file);
                                    }
                                    else
                                    {
                                        dealerCard3.Image = Image.FromFile(file);
                                    }
                                    break;
                                case 4:
                                    if (type == 0)
                                    {
                                        playerCard4.Image = Image.FromFile(file);
                                    }
                                    else
                                    {
                                        dealerCard4.Image = Image.FromFile(file);
                                    }
                                    break;
                                case 5:
                                    if (type == 0)
                                    {
                                        playerCard5.Image = Image.FromFile(file);
                                    }
                                    else
                                    {
                                        dealerCard5.Image = Image.FromFile(file);
                                    }
                                    break;
                            }
                            break;
                        case 4:
                            file = newPath + @"\Images\Cards\jack_spades.png";
                            switch (hand.Count)
                            {
                                case 3:
                                    if (type == 0)
                                    {
                                        playerCard3.Image = Image.FromFile(file);
                                    }
                                    else
                                    {
                                        dealerCard3.Image = Image.FromFile(file);
                                    }
                                    break;
                                case 4:
                                    if (type == 0)
                                    {
                                        playerCard4.Image = Image.FromFile(file);
                                    }
                                    else
                                    {
                                        dealerCard4.Image = Image.FromFile(file);
                                    }
                                    break;
                                case 5:
                                    if (type == 0)
                                    {
                                        playerCard5.Image = Image.FromFile(file);
                                    }
                                    else
                                    {
                                        dealerCard5.Image = Image.FromFile(file);
                                    }
                                    break;
                            }
                            break;
                    }
                    break;
                case 12:
                    switch (suit)
                    {
                        case 1:
                            file = newPath + @"\Images\Cards\queen_clubs.png";
                            switch (hand.Count)
                            {
                                case 3:
                                    if (type == 0)
                                    {
                                        playerCard3.Image = Image.FromFile(file);
                                    }
                                    else
                                    {
                                        dealerCard3.Image = Image.FromFile(file);
                                    }
                                    break;
                                case 4:
                                    if (type == 0)
                                    {
                                        playerCard4.Image = Image.FromFile(file);
                                    }
                                    else
                                    {
                                        dealerCard4.Image = Image.FromFile(file);
                                    }
                                    break;
                                case 5:
                                    if (type == 0)
                                    {
                                        playerCard5.Image = Image.FromFile(file);
                                    }
                                    else
                                    {
                                        dealerCard5.Image = Image.FromFile(file);
                                    }
                                    break;
                            }
                            break;
                        case 2:
                            file = newPath + @"\Images\Cards\queen_diamonds.png";
                            switch (hand.Count)
                            {
                                case 3:
                                    if (type == 0)
                                    {
                                        playerCard3.Image = Image.FromFile(file);
                                    }
                                    else
                                    {
                                        dealerCard3.Image = Image.FromFile(file);
                                    }
                                    break;
                                case 4:
                                    if (type == 0)
                                    {
                                        playerCard4.Image = Image.FromFile(file);
                                    }
                                    else
                                    {
                                        dealerCard4.Image = Image.FromFile(file);
                                    }
                                    break;
                                case 5:
                                    if (type == 0)
                                    {
                                        playerCard5.Image = Image.FromFile(file);
                                    }
                                    else
                                    {
                                        dealerCard5.Image = Image.FromFile(file);
                                    }
                                    break;
                            }
                            break;
                        case 3:
                            file = newPath + @"\Images\Cards\queen_hearts.png";
                            switch (hand.Count)
                            {
                                case 3:
                                    if (type == 0)
                                    {
                                        playerCard3.Image = Image.FromFile(file);
                                    }
                                    else
                                    {
                                        dealerCard3.Image = Image.FromFile(file);
                                    }
                                    break;
                                case 4:
                                    if (type == 0)
                                    {
                                        playerCard4.Image = Image.FromFile(file);
                                    }
                                    else
                                    {
                                        dealerCard4.Image = Image.FromFile(file);
                                    }
                                    break;
                                case 5:
                                    if (type == 0)
                                    {
                                        playerCard5.Image = Image.FromFile(file);
                                    }
                                    else
                                    {
                                        dealerCard5.Image = Image.FromFile(file);
                                    }
                                    break;
                            }
                            break;
                        case 4:
                            file = newPath + @"\Images\Cards\queen_spades.png";
                            switch (hand.Count)
                            {
                                case 3:
                                    if (type == 0)
                                    {
                                        playerCard3.Image = Image.FromFile(file);
                                    }
                                    else
                                    {
                                        dealerCard3.Image = Image.FromFile(file);
                                    }
                                    break;
                                case 4:
                                    if (type == 0)
                                    {
                                        playerCard4.Image = Image.FromFile(file);
                                    }
                                    else
                                    {
                                        dealerCard4.Image = Image.FromFile(file);
                                    }
                                    break;
                                case 5:
                                    if (type == 0)
                                    {
                                        playerCard5.Image = Image.FromFile(file);
                                    }
                                    else
                                    {
                                        dealerCard5.Image = Image.FromFile(file);
                                    }
                                    break;
                            }
                            break;
                    }
                    break;
                case 13:
                    switch (suit)
                    {
                        case 1:
                            file = newPath + @"\Images\Cards\king_clubs.png";
                            switch (hand.Count)
                            {
                                case 3:
                                    if (type == 0)
                                    {
                                        playerCard3.Image = Image.FromFile(file);
                                    }
                                    else
                                    {
                                        dealerCard3.Image = Image.FromFile(file);
                                    }
                                    break;
                                case 4:
                                    if (type == 0)
                                    {
                                        playerCard4.Image = Image.FromFile(file);
                                    }
                                    else
                                    {
                                        dealerCard4.Image = Image.FromFile(file);
                                    }
                                    break;
                                case 5:
                                    if (type == 0)
                                    {
                                        playerCard5.Image = Image.FromFile(file);
                                    }
                                    else
                                    {
                                        dealerCard5.Image = Image.FromFile(file);
                                    }
                                    break;
                            }
                            break;
                        case 2:
                            file = newPath + @"\Images\Cards\king_diamonds.png";
                            switch (hand.Count)
                            {
                                case 3:
                                    if (type == 0)
                                    {
                                        playerCard3.Image = Image.FromFile(file);
                                    }
                                    else
                                    {
                                        dealerCard3.Image = Image.FromFile(file);
                                    }
                                    break;
                                case 4:
                                    if (type == 0)
                                    {
                                        playerCard4.Image = Image.FromFile(file);
                                    }
                                    else
                                    {
                                        dealerCard4.Image = Image.FromFile(file);
                                    }
                                    break;
                                case 5:
                                    if (type == 0)
                                    {
                                        playerCard5.Image = Image.FromFile(file);
                                    }
                                    else
                                    {
                                        dealerCard5.Image = Image.FromFile(file);
                                    }
                                    break;
                            }
                            break;
                        case 3:
                            file = newPath + @"\Images\Cards\king_hearts.png";
                            switch (hand.Count)
                            {
                                case 3:
                                    if (type == 0)
                                    {
                                        playerCard3.Image = Image.FromFile(file);
                                    }
                                    else
                                    {
                                        dealerCard3.Image = Image.FromFile(file);
                                    }
                                    break;
                                case 4:
                                    if (type == 0)
                                    {
                                        playerCard4.Image = Image.FromFile(file);
                                    }
                                    else
                                    {
                                        dealerCard4.Image = Image.FromFile(file);
                                    }
                                    break;
                                case 5:
                                    if (type == 0)
                                    {
                                        playerCard5.Image = Image.FromFile(file);
                                    }
                                    else
                                    {
                                        dealerCard5.Image = Image.FromFile(file);
                                    }
                                    break;
                            }
                            break;
                        case 4:
                            file = newPath + @"\Images\Cards\king_spades.png";
                            switch (hand.Count)
                            {
                                case 3:
                                    if (type == 0)
                                    {
                                        playerCard3.Image = Image.FromFile(file);
                                    }
                                    else
                                    {
                                        dealerCard3.Image = Image.FromFile(file);
                                    }
                                    break;
                                case 4:
                                    if (type == 0)
                                    {
                                        playerCard4.Image = Image.FromFile(file);
                                    }
                                    else
                                    {
                                        dealerCard4.Image = Image.FromFile(file);
                                    }
                                    break;
                                case 5:
                                    if (type == 0)
                                    {
                                        playerCard5.Image = Image.FromFile(file);
                                    }
                                    else
                                    {
                                        dealerCard5.Image = Image.FromFile(file);
                                    }
                                    break;
                            }
                            break;
                    }
                    break;
            }
        }

        protected void getInitialCards()
        {
            ArrayList playerHand = BlackjackPlayer.getPlayerHand();
            ArrayList dealerHand = BlackjackPlayer.getDealerHand();
            string path = Directory.GetCurrentDirectory();
            string newPath = Path.GetFullPath(Path.Combine(path, @"..\..\"));  //C:\\Users\\Austin Dewey\\Documents\\Visual Studio 2015\\Projects\\Game\\Game
            //string file = newPath + @"\Images\Cards\ace_clubs.png";
            string file;

            /*
            playerHand.Clear();
            Card c0 = new Card(1, 1);
            Card c1 = new Card(3, 2);
            playerHand.Add(c0);
            playerHand.Add(c1);
            */

            // Get Player cards
            for (int i = 0; i < 2; i++)
            {
                Card c = (Card)playerHand[i];
                int num = c.cNum;
                int suit = c.sNum;

                switch (num)
                {
                    case 1:                             // Ace
                        switch (suit)
                        {
                            case 1:                     // Clubs
                                file = newPath + @"\Images\Cards\ace_clubs.png";
                                switch (i)
                                {
                                    case 0:
                                        playerCard1.Image = Image.FromFile(file);
                                        break;
                                    case 1:
                                        playerCard2.Image = Image.FromFile(file);
                                        break;
                                }
                                break;
                            case 2:                     // Diamonds
                                file = newPath + @"\Images\Cards\ace_diamonds.png";
                                switch (i)
                                {
                                    case 0:
                                        playerCard1.Image = Image.FromFile(file);
                                        break;
                                    case 1:
                                        playerCard2.Image = Image.FromFile(file);
                                        break;
                                }
                                break;
                            case 3:                     // Hearts
                                file = newPath + @"\Images\Cards\ace_hearts.png";
                                switch (i)
                                {
                                    case 0:
                                        playerCard1.Image = Image.FromFile(file);
                                        break;
                                    case 1:
                                        playerCard2.Image = Image.FromFile(file);
                                        break;
                                }
                                break;
                            case 4:                     // Spades
                                file = newPath + @"\Images\Cards\ace_spades.png";
                                switch (i)
                                {
                                    case 0:
                                        playerCard1.Image = Image.FromFile(file);
                                        break;
                                    case 1:
                                        playerCard2.Image = Image.FromFile(file);
                                        break;
                                }
                                break;
                        }
                        break;
                    case 2:
                        switch (suit)
                        {
                            case 1:                     // Clubs
                                file = newPath + @"\Images\Cards\two_clubs.png";
                                switch (i)
                                {
                                    case 0:
                                        playerCard1.Image = Image.FromFile(file);
                                        break;
                                    case 1:
                                        playerCard2.Image = Image.FromFile(file);
                                        break;
                                }
                                break;
                            case 2:                     // Diamonds
                                file = newPath + @"\Images\Cards\two_diamonds.png";
                                switch (i)
                                {
                                    case 0:
                                        playerCard1.Image = Image.FromFile(file);
                                        break;
                                    case 1:
                                        playerCard2.Image = Image.FromFile(file);
                                        break;
                                }
                                break;
                            case 3:                     // Hearts
                                file = newPath + @"\Images\Cards\two_hearts.png";
                                switch (i)
                                {
                                    case 0:
                                        playerCard1.Image = Image.FromFile(file);
                                        break;
                                    case 1:
                                        playerCard2.Image = Image.FromFile(file);
                                        break;
                                }
                                break;
                            case 4:                     // Spades
                                file = newPath + @"\Images\Cards\two_spades.png";
                                switch (i)
                                {
                                    case 0:
                                        playerCard1.Image = Image.FromFile(file);
                                        break;
                                    case 1:
                                        playerCard2.Image = Image.FromFile(file);
                                        break;
                                }
                                break;
                        }
                        break;
                    case 3:
                        switch (suit)
                        {
                            case 1:                     // Clubs
                                file = newPath + @"\Images\Cards\three_clubs.png";
                                switch (i)
                                {
                                    case 0:
                                        playerCard1.Image = Image.FromFile(file);
                                        break;
                                    case 1:
                                        playerCard2.Image = Image.FromFile(file);
                                        break;
                                }
                                break;
                            case 2:                     // Diamonds
                                file = newPath + @"\Images\Cards\three_diamonds.png";
                                switch (i)
                                {
                                    case 0:
                                        playerCard1.Image = Image.FromFile(file);
                                        break;
                                    case 1:
                                        playerCard2.Image = Image.FromFile(file);
                                        break;
                                }
                                break;
                            case 3:                     // Hearts
                                file = newPath + @"\Images\Cards\three_hearts.png";
                                switch (i)
                                {
                                    case 0:
                                        playerCard1.Image = Image.FromFile(file);
                                        break;
                                    case 1:
                                        playerCard2.Image = Image.FromFile(file);
                                        break;
                                }
                                break;
                            case 4:                     // Spades
                                file = newPath + @"\Images\Cards\three_spades.png";
                                switch (i)
                                {
                                    case 0:
                                        playerCard1.Image = Image.FromFile(file);
                                        break;
                                    case 1:
                                        playerCard2.Image = Image.FromFile(file);
                                        break;
                                }
                                break;
                        }
                        break;
                    case 4:
                        switch (suit)
                        {
                            case 1:                     // Clubs
                                file = newPath + @"\Images\Cards\four_clubs.png";
                                switch (i)
                                {
                                    case 0:
                                        playerCard1.Image = Image.FromFile(file);
                                        break;
                                    case 1:
                                        playerCard2.Image = Image.FromFile(file);
                                        break;
                                }
                                break;
                            case 2:                     // Diamonds
                                file = newPath + @"\Images\Cards\four_diamonds.png";
                                switch (i)
                                {
                                    case 0:
                                        playerCard1.Image = Image.FromFile(file);
                                        break;
                                    case 1:
                                        playerCard2.Image = Image.FromFile(file);
                                        break;
                                }
                                break;
                            case 3:                     // Hearts
                                file = newPath + @"\Images\Cards\four_hearts.png";
                                switch (i)
                                {
                                    case 0:
                                        playerCard1.Image = Image.FromFile(file);
                                        break;
                                    case 1:
                                        playerCard2.Image = Image.FromFile(file);
                                        break;
                                }
                                break;
                            case 4:                     // Spades
                                file = newPath + @"\Images\Cards\four_spades.png";
                                switch (i)
                                {
                                    case 0:
                                        playerCard1.Image = Image.FromFile(file);
                                        break;
                                    case 1:
                                        playerCard2.Image = Image.FromFile(file);
                                        break;
                                }
                                break;
                        }
                        break;
                    case 5:
                        switch (suit)
                        {
                            case 1:                     // Clubs
                                file = newPath + @"\Images\Cards\five_clubs.png";
                                switch (i)
                                {
                                    case 0:
                                        playerCard1.Image = Image.FromFile(file);
                                        break;
                                    case 1:
                                        playerCard2.Image = Image.FromFile(file);
                                        break;
                                }
                                break;
                            case 2:                     // Diamonds
                                file = newPath + @"\Images\Cards\five_diamonds.png";
                                switch (i)
                                {
                                    case 0:
                                        playerCard1.Image = Image.FromFile(file);
                                        break;
                                    case 1:
                                        playerCard2.Image = Image.FromFile(file);
                                        break;
                                }
                                break;
                            case 3:                     // Hearts
                                file = newPath + @"\Images\Cards\five_hearts.png";
                                switch (i)
                                {
                                    case 0:
                                        playerCard1.Image = Image.FromFile(file);
                                        break;
                                    case 1:
                                        playerCard2.Image = Image.FromFile(file);
                                        break;
                                }
                                break;
                            case 4:                     // Spades
                                file = newPath + @"\Images\Cards\five_spades.png";
                                switch (i)
                                {
                                    case 0:
                                        playerCard1.Image = Image.FromFile(file);
                                        break;
                                    case 1:
                                        playerCard2.Image = Image.FromFile(file);
                                        break;
                                }
                                break;
                        }
                        break;
                    case 6:
                        switch (suit)
                        {
                            case 1:                     // Clubs
                                file = newPath + @"\Images\Cards\six_clubs.png";
                                switch (i)
                                {
                                    case 0:
                                        playerCard1.Image = Image.FromFile(file);
                                        break;
                                    case 1:
                                        playerCard2.Image = Image.FromFile(file);
                                        break;
                                }
                                break;
                            case 2:                     // Diamonds
                                file = newPath + @"\Images\Cards\six_diamonds.png";
                                switch (i)
                                {
                                    case 0:
                                        playerCard1.Image = Image.FromFile(file);
                                        break;
                                    case 1:
                                        playerCard2.Image = Image.FromFile(file);
                                        break;
                                }
                                break;
                            case 3:                     // Hearts
                                file = newPath + @"\Images\Cards\six_hearts.png";
                                switch (i)
                                {
                                    case 0:
                                        playerCard1.Image = Image.FromFile(file);
                                        break;
                                    case 1:
                                        playerCard2.Image = Image.FromFile(file);
                                        break;
                                }
                                break;
                            case 4:                     // Spades
                                file = newPath + @"\Images\Cards\six_spades.png";
                                switch (i)
                                {
                                    case 0:
                                        playerCard1.Image = Image.FromFile(file);
                                        break;
                                    case 1:
                                        playerCard2.Image = Image.FromFile(file);
                                        break;
                                }
                                break;
                        }
                        break;
                    case 7:
                        switch (suit)
                        {
                            case 1:                     // Clubs
                                file = newPath + @"\Images\Cards\seven_clubs.png";
                                switch (i)
                                {
                                    case 0:
                                        playerCard1.Image = Image.FromFile(file);
                                        break;
                                    case 1:
                                        playerCard2.Image = Image.FromFile(file);
                                        break;
                                }
                                break;
                            case 2:                     // Diamonds
                                file = newPath + @"\Images\Cards\seven_diamonds.png";
                                switch (i)
                                {
                                    case 0:
                                        playerCard1.Image = Image.FromFile(file);
                                        break;
                                    case 1:
                                        playerCard2.Image = Image.FromFile(file);
                                        break;
                                }
                                break;
                            case 3:                     // Hearts
                                file = newPath + @"\Images\Cards\seven_hearts.png";
                                switch (i)
                                {
                                    case 0:
                                        playerCard1.Image = Image.FromFile(file);
                                        break;
                                    case 1:
                                        playerCard2.Image = Image.FromFile(file);
                                        break;
                                }
                                break;
                            case 4:                     // Spades
                                file = newPath + @"\Images\Cards\seven_spades.png";
                                switch (i)
                                {
                                    case 0:
                                        playerCard1.Image = Image.FromFile(file);
                                        break;
                                    case 1:
                                        playerCard2.Image = Image.FromFile(file);
                                        break;
                                }
                                break;
                        }
                        break;
                    case 8:
                        switch (suit)
                        {
                            case 1:                     // Clubs
                                file = newPath + @"\Images\Cards\eight_clubs.png";
                                switch (i)
                                {
                                    case 0:
                                        playerCard1.Image = Image.FromFile(file);
                                        break;
                                    case 1:
                                        playerCard2.Image = Image.FromFile(file);
                                        break;
                                }
                                break;
                            case 2:                     // Diamonds
                                file = newPath + @"\Images\Cards\eight_diamonds.png";
                                switch (i)
                                {
                                    case 0:
                                        playerCard1.Image = Image.FromFile(file);
                                        break;
                                    case 1:
                                        playerCard2.Image = Image.FromFile(file);
                                        break;
                                }
                                break;
                            case 3:                     // Hearts
                                file = newPath + @"\Images\Cards\eight_hearts.png";
                                switch (i)
                                {
                                    case 0:
                                        playerCard1.Image = Image.FromFile(file);
                                        break;
                                    case 1:
                                        playerCard2.Image = Image.FromFile(file);
                                        break;
                                }
                                break;
                            case 4:                     // Spades
                                file = newPath + @"\Images\Cards\eight_spades.png";
                                switch (i)
                                {
                                    case 0:
                                        playerCard1.Image = Image.FromFile(file);
                                        break;
                                    case 1:
                                        playerCard2.Image = Image.FromFile(file);
                                        break;
                                }
                                break;
                        }
                        break;
                    case 9:
                        switch (suit)
                        {
                            case 1:                     // Clubs
                                file = newPath + @"\Images\Cards\nine_clubs.png";
                                switch (i)
                                {
                                    case 0:
                                        playerCard1.Image = Image.FromFile(file);
                                        break;
                                    case 1:
                                        playerCard2.Image = Image.FromFile(file);
                                        break;
                                }
                                break;
                            case 2:                     // Diamonds
                                file = newPath + @"\Images\Cards\nine_diamonds.png";
                                switch (i)
                                {
                                    case 0:
                                        playerCard1.Image = Image.FromFile(file);
                                        break;
                                    case 1:
                                        playerCard2.Image = Image.FromFile(file);
                                        break;
                                }
                                break;
                            case 3:                     // Hearts
                                file = newPath + @"\Images\Cards\nine_hearts.png";
                                switch (i)
                                {
                                    case 0:
                                        playerCard1.Image = Image.FromFile(file);
                                        break;
                                    case 1:
                                        playerCard2.Image = Image.FromFile(file);
                                        break;
                                }
                                break;
                            case 4:                     // Spades
                                file = newPath + @"\Images\Cards\nine_spades.png";
                                switch (i)
                                {
                                    case 0:
                                        playerCard1.Image = Image.FromFile(file);
                                        break;
                                    case 1:
                                        playerCard2.Image = Image.FromFile(file);
                                        break;
                                }
                                break;
                        }
                        break;
                    case 10:
                        switch (suit)
                        {
                            case 1:                     // Clubs
                                file = newPath + @"\Images\Cards\ten_clubs.png";
                                switch (i)
                                {
                                    case 0:
                                        playerCard1.Image = Image.FromFile(file);
                                        break;
                                    case 1:
                                        playerCard2.Image = Image.FromFile(file);
                                        break;
                                }
                                break;
                            case 2:                     // Diamonds
                                file = newPath + @"\Images\Cards\ten_diamonds.png";
                                switch (i)
                                {
                                    case 0:
                                        playerCard1.Image = Image.FromFile(file);
                                        break;
                                    case 1:
                                        playerCard2.Image = Image.FromFile(file);
                                        break;
                                }
                                break;
                            case 3:                     // Hearts
                                file = newPath + @"\Images\Cards\ten_hearts.png";
                                switch (i)
                                {
                                    case 0:
                                        playerCard1.Image = Image.FromFile(file);
                                        break;
                                    case 1:
                                        playerCard2.Image = Image.FromFile(file);
                                        break;
                                }
                                break;
                            case 4:                     // Spades
                                file = newPath + @"\Images\Cards\ten_spades.png";
                                switch (i)
                                {
                                    case 0:
                                        playerCard1.Image = Image.FromFile(file);
                                        break;
                                    case 1:
                                        playerCard2.Image = Image.FromFile(file);
                                        break;
                                }
                                break;
                        }
                        break;
                    case 11:
                        switch (suit)
                        {
                            case 1:                     // Clubs
                                file = newPath + @"\Images\Cards\jack_clubs.png";
                                switch (i)
                                {
                                    case 0:
                                        playerCard1.Image = Image.FromFile(file);
                                        break;
                                    case 1:
                                        playerCard2.Image = Image.FromFile(file);
                                        break;
                                }
                                break;
                            case 2:                     // Diamonds
                                file = newPath + @"\Images\Cards\jack_diamonds.png";
                                switch (i)
                                {
                                    case 0:
                                        playerCard1.Image = Image.FromFile(file);
                                        break;
                                    case 1:
                                        playerCard2.Image = Image.FromFile(file);
                                        break;
                                }
                                break;
                            case 3:                     // Hearts
                                file = newPath + @"\Images\Cards\jack_hearts.png";
                                switch (i)
                                {
                                    case 0:
                                        playerCard1.Image = Image.FromFile(file);
                                        break;
                                    case 1:
                                        playerCard2.Image = Image.FromFile(file);
                                        break;
                                }
                                break;
                            case 4:                     // Spades
                                file = newPath + @"\Images\Cards\jack_spades.png";
                                switch (i)
                                {
                                    case 0:
                                        playerCard1.Image = Image.FromFile(file);
                                        break;
                                    case 1:
                                        playerCard2.Image = Image.FromFile(file);
                                        break;
                                }
                                break;
                        }
                        break;
                    case 12:
                        switch (suit)
                        {
                            case 1:                     // Clubs
                                file = newPath + @"\Images\Cards\queen_clubs.png";
                                switch (i)
                                {
                                    case 0:
                                        playerCard1.Image = Image.FromFile(file);
                                        break;
                                    case 1:
                                        playerCard2.Image = Image.FromFile(file);
                                        break;
                                }
                                break;
                            case 2:                     // Diamonds
                                file = newPath + @"\Images\Cards\queen_diamonds.png";
                                switch (i)
                                {
                                    case 0:
                                        playerCard1.Image = Image.FromFile(file);
                                        break;
                                    case 1:
                                        playerCard2.Image = Image.FromFile(file);
                                        break;
                                }
                                break;
                            case 3:                     // Hearts
                                file = newPath + @"\Images\Cards\queen_hearts.png";
                                switch (i)
                                {
                                    case 0:
                                        playerCard1.Image = Image.FromFile(file);
                                        break;
                                    case 1:
                                        playerCard2.Image = Image.FromFile(file);
                                        break;
                                }
                                break;
                            case 4:                     // Spades
                                file = newPath + @"\Images\Cards\queen_spades.png";
                                switch (i)
                                {
                                    case 0:
                                        playerCard1.Image = Image.FromFile(file);
                                        break;
                                    case 1:
                                        playerCard2.Image = Image.FromFile(file);
                                        break;
                                }
                                break;
                        }
                        break;
                    case 13:
                        switch (suit)
                        {
                            case 1:                     // Clubs
                                file = newPath + @"\Images\Cards\king_clubs.png";
                                switch (i)
                                {
                                    case 0:
                                        playerCard1.Image = Image.FromFile(file);
                                        break;
                                    case 1:
                                        playerCard2.Image = Image.FromFile(file);
                                        break;
                                }
                                break;
                            case 2:                     // Diamonds
                                file = newPath + @"\Images\Cards\king_diamonds.png";
                                switch (i)
                                {
                                    case 0:
                                        playerCard1.Image = Image.FromFile(file);
                                        break;
                                    case 1:
                                        playerCard2.Image = Image.FromFile(file);
                                        break;
                                }
                                break;
                            case 3:                     // Hearts
                                file = newPath + @"\Images\Cards\king_hearts.png";
                                switch (i)
                                {
                                    case 0:
                                        playerCard1.Image = Image.FromFile(file);
                                        break;
                                    case 1:
                                        playerCard2.Image = Image.FromFile(file);
                                        break;
                                }
                                break;
                            case 4:                     // Spades
                                file = newPath + @"\Images\Cards\king_spades.png";
                                switch (i)
                                {
                                    case 0:
                                        playerCard1.Image = Image.FromFile(file);
                                        break;
                                    case 1:
                                        playerCard2.Image = Image.FromFile(file);
                                        break;
                                }
                                break;
                        }
                        break;
                }
            }

            Card card = (Card)dealerHand[0];
            int n = card.cNum;
            int s = card.sNum;
            switch (n)
            {
                case 1:
                    switch (s)
                    {
                        case 1:
                            file = newPath + @"\Images\Cards\ace_clubs.png";
                            dealerCard1.Image = Image.FromFile(file);
                            break;
                        case 2:
                            file = newPath + @"\Images\Cards\ace_diamonds.png";
                            dealerCard1.Image = Image.FromFile(file);
                            break;
                        case 3:
                            file = newPath + @"\Images\Cards\ace_hearts.png";
                            dealerCard1.Image = Image.FromFile(file);
                            break;
                        case 4:
                            file = newPath + @"\Images\Cards\ace_spades.png";
                            dealerCard1.Image = Image.FromFile(file);
                            break;
                    }
                    break;
                case 2:
                    switch (s)
                    {
                        case 1:
                            file = newPath + @"\Images\Cards\two_clubs.png";
                            dealerCard1.Image = Image.FromFile(file);
                            break;
                        case 2:
                            file = newPath + @"\Images\Cards\two_diamonds.png";
                            dealerCard1.Image = Image.FromFile(file);
                            break;
                        case 3:
                            file = newPath + @"\Images\Cards\two_hearts.png";
                            dealerCard1.Image = Image.FromFile(file);
                            break;
                        case 4:
                            file = newPath + @"\Images\Cards\two_spades.png";
                            dealerCard1.Image = Image.FromFile(file);
                            break;
                    }
                    break;
                case 3:
                    switch (s)
                    {
                        case 1:
                            file = newPath + @"\Images\Cards\three_clubs.png";
                            dealerCard1.Image = Image.FromFile(file);
                            break;
                        case 2:
                            file = newPath + @"\Images\Cards\three_diamonds.png";
                            dealerCard1.Image = Image.FromFile(file);
                            break;
                        case 3:
                            file = newPath + @"\Images\Cards\three_hearts.png";
                            dealerCard1.Image = Image.FromFile(file);
                            break;
                        case 4:
                            file = newPath + @"\Images\Cards\three_spades.png";
                            dealerCard1.Image = Image.FromFile(file);
                            break;
                    }
                    break;
                case 4:
                    switch (s)
                    {
                        case 1:
                            file = newPath + @"\Images\Cards\four_clubs.png";
                            dealerCard1.Image = Image.FromFile(file);
                            break;
                        case 2:
                            file = newPath + @"\Images\Cards\four_diamonds.png";
                            dealerCard1.Image = Image.FromFile(file);
                            break;
                        case 3:
                            file = newPath + @"\Images\Cards\four_hearts.png";
                            dealerCard1.Image = Image.FromFile(file);
                            break;
                        case 4:
                            file = newPath + @"\Images\Cards\four_spades.png";
                            dealerCard1.Image = Image.FromFile(file);
                            break;
                    }
                    break;
                case 5:
                    switch (s)
                    {
                        case 1:
                            file = newPath + @"\Images\Cards\five_clubs.png";
                            dealerCard1.Image = Image.FromFile(file);
                            break;
                        case 2:
                            file = newPath + @"\Images\Cards\five_diamonds.png";
                            dealerCard1.Image = Image.FromFile(file);
                            break;
                        case 3:
                            file = newPath + @"\Images\Cards\five_hearts.png";
                            dealerCard1.Image = Image.FromFile(file);
                            break;
                        case 4:
                            file = newPath + @"\Images\Cards\five_spades.png";
                            dealerCard1.Image = Image.FromFile(file);
                            break;
                    }
                    break;
                case 6:
                    switch (s)
                    {
                        case 1:
                            file = newPath + @"\Images\Cards\six_clubs.png";
                            dealerCard1.Image = Image.FromFile(file);
                            break;
                        case 2:
                            file = newPath + @"\Images\Cards\six_diamonds.png";
                            dealerCard1.Image = Image.FromFile(file);
                            break;
                        case 3:
                            file = newPath + @"\Images\Cards\six_hearts.png";
                            dealerCard1.Image = Image.FromFile(file);
                            break;
                        case 4:
                            file = newPath + @"\Images\Cards\six_spades.png";
                            dealerCard1.Image = Image.FromFile(file);
                            break;
                    }
                    break;
                case 7:
                    switch (s)
                    {
                        case 1:
                            file = newPath + @"\Images\Cards\seven_clubs.png";
                            dealerCard1.Image = Image.FromFile(file);
                            break;
                        case 2:
                            file = newPath + @"\Images\Cards\seven_diamonds.png";
                            dealerCard1.Image = Image.FromFile(file);
                            break;
                        case 3:
                            file = newPath + @"\Images\Cards\seven_hearts.png";
                            dealerCard1.Image = Image.FromFile(file);
                            break;
                        case 4:
                            file = newPath + @"\Images\Cards\seven_spades.png";
                            dealerCard1.Image = Image.FromFile(file);
                            break;
                    }
                    break;
                case 8:
                    switch (s)
                    {
                        case 1:
                            file = newPath + @"\Images\Cards\eight_clubs.png";
                            dealerCard1.Image = Image.FromFile(file);
                            break;
                        case 2:
                            file = newPath + @"\Images\Cards\eight_diamonds.png";
                            dealerCard1.Image = Image.FromFile(file);
                            break;
                        case 3:
                            file = newPath + @"\Images\Cards\eight_hearts.png";
                            dealerCard1.Image = Image.FromFile(file);
                            break;
                        case 4:
                            file = newPath + @"\Images\Cards\eight_spades.png";
                            dealerCard1.Image = Image.FromFile(file);
                            break;
                    }
                    break;
                case 9:
                    switch (s)
                    {
                        case 1:
                            file = newPath + @"\Images\Cards\nine_clubs.png";
                            dealerCard1.Image = Image.FromFile(file);
                            break;
                        case 2:
                            file = newPath + @"\Images\Cards\nine_diamonds.png";
                            dealerCard1.Image = Image.FromFile(file);
                            break;
                        case 3:
                            file = newPath + @"\Images\Cards\nine_hearts.png";
                            dealerCard1.Image = Image.FromFile(file);
                            break;
                        case 4:
                            file = newPath + @"\Images\Cards\nine_spades.png";
                            dealerCard1.Image = Image.FromFile(file);
                            break;
                    }
                    break;
                case 10:
                    switch (s)
                    {
                        case 1:
                            file = newPath + @"\Images\Cards\ten_clubs.png";
                            dealerCard1.Image = Image.FromFile(file);
                            break;
                        case 2:
                            file = newPath + @"\Images\Cards\ten_diamonds.png";
                            dealerCard1.Image = Image.FromFile(file);
                            break;
                        case 3:
                            file = newPath + @"\Images\Cards\ten_hearts.png";
                            dealerCard1.Image = Image.FromFile(file);
                            break;
                        case 4:
                            file = newPath + @"\Images\Cards\ten_spades.png";
                            dealerCard1.Image = Image.FromFile(file);
                            break;
                    }
                    break;
                case 11:
                    switch (s)
                    {
                        case 1:
                            file = newPath + @"\Images\Cards\jack_clubs.png";
                            dealerCard1.Image = Image.FromFile(file);
                            break;
                        case 2:
                            file = newPath + @"\Images\Cards\jack_diamonds.png";
                            dealerCard1.Image = Image.FromFile(file);
                            break;
                        case 3:
                            file = newPath + @"\Images\Cards\jack_hearts.png";
                            dealerCard1.Image = Image.FromFile(file);
                            break;
                        case 4:
                            file = newPath + @"\Images\Cards\jack_spades.png";
                            dealerCard1.Image = Image.FromFile(file);
                            break;
                    }
                    break;
                case 12:
                    switch (s)
                    {
                        case 1:
                            file = newPath + @"\Images\Cards\queen_clubs.png";
                            dealerCard1.Image = Image.FromFile(file);
                            break;
                        case 2:
                            file = newPath + @"\Images\Cards\queen_diamonds.png";
                            dealerCard1.Image = Image.FromFile(file);
                            break;
                        case 3:
                            file = newPath + @"\Images\Cards\queen_hearts.png";
                            dealerCard1.Image = Image.FromFile(file);
                            break;
                        case 4:
                            file = newPath + @"\Images\Cards\queen_spades.png";
                            dealerCard1.Image = Image.FromFile(file);
                            break;
                    }
                    break;
                case 13:
                    switch (s)
                    {
                        case 1:
                            file = newPath + @"\Images\Cards\king_clubs.png";
                            dealerCard1.Image = Image.FromFile(file);
                            break;
                        case 2:
                            file = newPath + @"\Images\Cards\king_diamonds.png";
                            dealerCard1.Image = Image.FromFile(file);
                            break;
                        case 3:
                            file = newPath + @"\Images\Cards\king_hearts.png";
                            dealerCard1.Image = Image.FromFile(file);
                            break;
                        case 4:
                            file = newPath + @"\Images\Cards\king_spades.png";
                            dealerCard1.Image = Image.FromFile(file);
                            break;
                    }
                    break;
            }
            card = (Card)dealerHand[0];
            n = card.cNum;
            s = card.sNum;
            switch (n)
            {
                case 1:
                    switch (s)
                    {
                        case 1:
                            file = newPath + @"\Images\Cards\ace_clubs.png";
                            dealerCard2.Image = Image.FromFile(file);
                            break;
                        case 2:
                            file = newPath + @"\Images\Cards\ace_diamonds.png";
                            dealerCard2.Image = Image.FromFile(file);
                            break;
                        case 3:
                            file = newPath + @"\Images\Cards\ace_hearts.png";
                            dealerCard2.Image = Image.FromFile(file);
                            break;
                        case 4:
                            file = newPath + @"\Images\Cards\ace_spades.png";
                            dealerCard2.Image = Image.FromFile(file);
                            break;
                    }
                    break;
                case 2:
                    switch (s)
                    {
                        case 1:
                            file = newPath + @"\Images\Cards\two_clubs.png";
                            dealerCard2.Image = Image.FromFile(file);
                            break;
                        case 2:
                            file = newPath + @"\Images\Cards\two_diamonds.png";
                            dealerCard2.Image = Image.FromFile(file);
                            break;
                        case 3:
                            file = newPath + @"\Images\Cards\two_hearts.png";
                            dealerCard2.Image = Image.FromFile(file);
                            break;
                        case 4:
                            file = newPath + @"\Images\Cards\two_spades.png";
                            dealerCard2.Image = Image.FromFile(file);
                            break;
                    }
                    break;
                case 3:
                    switch (s)
                    {
                        case 1:
                            file = newPath + @"\Images\Cards\three_clubs.png";
                            dealerCard2.Image = Image.FromFile(file);
                            break;
                        case 2:
                            file = newPath + @"\Images\Cards\three_diamonds.png";
                            dealerCard2.Image = Image.FromFile(file);
                            break;
                        case 3:
                            file = newPath + @"\Images\Cards\three_hearts.png";
                            dealerCard2.Image = Image.FromFile(file);
                            break;
                        case 4:
                            file = newPath + @"\Images\Cards\three_spades.png";
                            dealerCard2.Image = Image.FromFile(file);
                            break;
                    }
                    break;
                case 4:
                    switch (s)
                    {
                        case 1:
                            file = newPath + @"\Images\Cards\four_clubs.png";
                            dealerCard2.Image = Image.FromFile(file);
                            break;
                        case 2:
                            file = newPath + @"\Images\Cards\four_diamonds.png";
                            dealerCard2.Image = Image.FromFile(file);
                            break;
                        case 3:
                            file = newPath + @"\Images\Cards\four_hearts.png";
                            dealerCard2.Image = Image.FromFile(file);
                            break;
                        case 4:
                            file = newPath + @"\Images\Cards\four_spades.png";
                            dealerCard2.Image = Image.FromFile(file);
                            break;
                    }
                    break;
                case 5:
                    switch (s)
                    {
                        case 1:
                            file = newPath + @"\Images\Cards\five_clubs.png";
                            dealerCard2.Image = Image.FromFile(file);
                            break;
                        case 2:
                            file = newPath + @"\Images\Cards\five_diamonds.png";
                            dealerCard2.Image = Image.FromFile(file);
                            break;
                        case 3:
                            file = newPath + @"\Images\Cards\five_hearts.png";
                            dealerCard2.Image = Image.FromFile(file);
                            break;
                        case 4:
                            file = newPath + @"\Images\Cards\five_spades.png";
                            dealerCard2.Image = Image.FromFile(file);
                            break;
                    }
                    break;
                case 6:
                    switch (s)
                    {
                        case 1:
                            file = newPath + @"\Images\Cards\six_clubs.png";
                            dealerCard2.Image = Image.FromFile(file);
                            break;
                        case 2:
                            file = newPath + @"\Images\Cards\six_diamonds.png";
                            dealerCard2.Image = Image.FromFile(file);
                            break;
                        case 3:
                            file = newPath + @"\Images\Cards\six_hearts.png";
                            dealerCard2.Image = Image.FromFile(file);
                            break;
                        case 4:
                            file = newPath + @"\Images\Cards\six_spades.png";
                            dealerCard2.Image = Image.FromFile(file);
                            break;
                    }
                    break;
                case 7:
                    switch (s)
                    {
                        case 1:
                            file = newPath + @"\Images\Cards\seven_clubs.png";
                            dealerCard2.Image = Image.FromFile(file);
                            break;
                        case 2:
                            file = newPath + @"\Images\Cards\seven_diamonds.png";
                            dealerCard2.Image = Image.FromFile(file);
                            break;
                        case 3:
                            file = newPath + @"\Images\Cards\seven_hearts.png";
                            dealerCard2.Image = Image.FromFile(file);
                            break;
                        case 4:
                            file = newPath + @"\Images\Cards\seven_spades.png";
                            dealerCard2.Image = Image.FromFile(file);
                            break;
                    }
                    break;
                case 8:
                    switch (s)
                    {
                        case 1:
                            file = newPath + @"\Images\Cards\eight_clubs.png";
                            dealerCard2.Image = Image.FromFile(file);
                            break;
                        case 2:
                            file = newPath + @"\Images\Cards\eight_diamonds.png";
                            dealerCard2.Image = Image.FromFile(file);
                            break;
                        case 3:
                            file = newPath + @"\Images\Cards\eight_hearts.png";
                            dealerCard2.Image = Image.FromFile(file);
                            break;
                        case 4:
                            file = newPath + @"\Images\Cards\eight_spades.png";
                            dealerCard2.Image = Image.FromFile(file);
                            break;
                    }
                    break;
                case 9:
                    switch (s)
                    {
                        case 1:
                            file = newPath + @"\Images\Cards\nine_clubs.png";
                            dealerCard2.Image = Image.FromFile(file);
                            break;
                        case 2:
                            file = newPath + @"\Images\Cards\nine_diamonds.png";
                            dealerCard2.Image = Image.FromFile(file);
                            break;
                        case 3:
                            file = newPath + @"\Images\Cards\nine_hearts.png";
                            dealerCard2.Image = Image.FromFile(file);
                            break;
                        case 4:
                            file = newPath + @"\Images\Cards\nine_spades.png";
                            dealerCard2.Image = Image.FromFile(file);
                            break;
                    }
                    break;
                case 10:
                    switch (s)
                    {
                        case 1:
                            file = newPath + @"\Images\Cards\ten_clubs.png";
                            dealerCard2.Image = Image.FromFile(file);
                            break;
                        case 2:
                            file = newPath + @"\Images\Cards\ten_diamonds.png";
                            dealerCard2.Image = Image.FromFile(file);
                            break;
                        case 3:
                            file = newPath + @"\Images\Cards\ten_hearts.png";
                            dealerCard2.Image = Image.FromFile(file);
                            break;
                        case 4:
                            file = newPath + @"\Images\Cards\ten_spades.png";
                            dealerCard2.Image = Image.FromFile(file);
                            break;
                    }
                    break;
                case 11:
                    switch (s)
                    {
                        case 1:
                            file = newPath + @"\Images\Cards\jack_clubs.png";
                            dealerCard2.Image = Image.FromFile(file);
                            break;
                        case 2:
                            file = newPath + @"\Images\Cards\jack_diamonds.png";
                            dealerCard2.Image = Image.FromFile(file);
                            break;
                        case 3:
                            file = newPath + @"\Images\Cards\jack_hearts.png";
                            dealerCard2.Image = Image.FromFile(file);
                            break;
                        case 4:
                            file = newPath + @"\Images\Cards\jack_spades.png";
                            dealerCard2.Image = Image.FromFile(file);
                            break;
                    }
                    break;
                case 12:
                    switch (s)
                    {
                        case 1:
                            file = newPath + @"\Images\Cards\queen_clubs.png";
                            dealerCard2.Image = Image.FromFile(file);
                            break;
                        case 2:
                            file = newPath + @"\Images\Cards\queen_diamonds.png";
                            dealerCard2.Image = Image.FromFile(file);
                            break;
                        case 3:
                            file = newPath + @"\Images\Cards\queen_hearts.png";
                            dealerCard2.Image = Image.FromFile(file);
                            break;
                        case 4:
                            file = newPath + @"\Images\Cards\queen_spades.png";
                            dealerCard2.Image = Image.FromFile(file);
                            break;
                    }
                    break;
                case 13:
                    switch (s)
                    {
                        case 1:
                            file = newPath + @"\Images\Cards\king_clubs.png";
                            dealerCard2.Image = Image.FromFile(file);
                            break;
                        case 2:
                            file = newPath + @"\Images\Cards\king_diamonds.png";
                            dealerCard2.Image = Image.FromFile(file);
                            break;
                        case 3:
                            file = newPath + @"\Images\Cards\king_hearts.png";
                            dealerCard2.Image = Image.FromFile(file);
                            break;
                        case 4:
                            file = newPath + @"\Images\Cards\king_spades.png";
                            dealerCard2.Image = Image.FromFile(file);
                            break;
                    }
                    break;
            }
        }
    }
}