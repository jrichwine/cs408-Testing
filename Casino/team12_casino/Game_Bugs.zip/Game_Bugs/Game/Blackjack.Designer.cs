﻿namespace Game
{
    partial class Blackjack
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Blackjack));
            this.hitBtn = new System.Windows.Forms.Button();
            this.standBtn = new System.Windows.Forms.Button();
            this.newGameBtn = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.playerCard1 = new System.Windows.Forms.PictureBox();
            this.playerCard2 = new System.Windows.Forms.PictureBox();
            this.playerCard3 = new System.Windows.Forms.PictureBox();
            this.playerCard4 = new System.Windows.Forms.PictureBox();
            this.dealerCard1 = new System.Windows.Forms.PictureBox();
            this.dealerCard2 = new System.Windows.Forms.PictureBox();
            this.dealerCard3 = new System.Windows.Forms.PictureBox();
            this.dealerCard4 = new System.Windows.Forms.PictureBox();
            this.dealerCard5 = new System.Windows.Forms.PictureBox();
            this.playerCard5 = new System.Windows.Forms.PictureBox();
            this.playerTotal = new System.Windows.Forms.Label();
            this.playerSlash = new System.Windows.Forms.Label();
            this.playerTotal2 = new System.Windows.Forms.Label();
            this.dealerTotal = new System.Windows.Forms.Label();
            this.dealerSlash = new System.Windows.Forms.Label();
            this.dealerTotal2 = new System.Windows.Forms.Label();
            this.playerBust = new System.Windows.Forms.Label();
            this.playerBlackjack = new System.Windows.Forms.Label();
            this.dealerBust = new System.Windows.Forms.Label();
            this.dealerBlackjack = new System.Windows.Forms.Label();
            this.winLabel = new System.Windows.Forms.Label();
            this.pushLabel = new System.Windows.Forms.Label();
            this.gameOverLabel = new System.Windows.Forms.Label();
            this.helpBtn = new System.Windows.Forms.Button();
            this.winLoseTimer = new System.Windows.Forms.Timer(this.components);
            this.creditLabel = new System.Windows.Forms.Label();
            this.winAmountLabel = new System.Windows.Forms.Label();
            this.betLabel = new System.Windows.Forms.Label();
            this.betMaxButton = new System.Windows.Forms.Button();
            this.betOneButton = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.playerCard1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.playerCard2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.playerCard3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.playerCard4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dealerCard1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dealerCard2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dealerCard3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dealerCard4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dealerCard5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.playerCard5)).BeginInit();
            this.SuspendLayout();
            // 
            // hitBtn
            // 
            this.hitBtn.BackColor = System.Drawing.Color.Gold;
            this.hitBtn.Enabled = false;
            this.hitBtn.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.hitBtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.hitBtn.Location = new System.Drawing.Point(124, 367);
            this.hitBtn.Name = "hitBtn";
            this.hitBtn.Size = new System.Drawing.Size(86, 28);
            this.hitBtn.TabIndex = 0;
            this.hitBtn.Text = "HIT";
            this.hitBtn.UseVisualStyleBackColor = false;
            this.hitBtn.Click += new System.EventHandler(this.hitBtn_Click);
            // 
            // standBtn
            // 
            this.standBtn.BackColor = System.Drawing.Color.Gold;
            this.standBtn.Enabled = false;
            this.standBtn.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.standBtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.standBtn.Location = new System.Drawing.Point(216, 367);
            this.standBtn.Name = "standBtn";
            this.standBtn.Size = new System.Drawing.Size(101, 28);
            this.standBtn.TabIndex = 1;
            this.standBtn.Text = "STAND";
            this.standBtn.UseVisualStyleBackColor = false;
            this.standBtn.Click += new System.EventHandler(this.standBtn_Click);
            // 
            // newGameBtn
            // 
            this.newGameBtn.BackColor = System.Drawing.Color.Gold;
            this.newGameBtn.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.newGameBtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.newGameBtn.Location = new System.Drawing.Point(349, 367);
            this.newGameBtn.Name = "newGameBtn";
            this.newGameBtn.Size = new System.Drawing.Size(133, 28);
            this.newGameBtn.TabIndex = 2;
            this.newGameBtn.Text = "NEW GAME";
            this.newGameBtn.UseVisualStyleBackColor = false;
            this.newGameBtn.Click += new System.EventHandler(this.newGameBtn_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Gold;
            this.label1.Location = new System.Drawing.Point(49, 34);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(68, 17);
            this.label1.TabIndex = 3;
            this.label1.Text = "PLAYER";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.Gold;
            this.label2.Location = new System.Drawing.Point(298, 34);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(69, 17);
            this.label2.TabIndex = 4;
            this.label2.Text = "DEALER";
            // 
            // playerCard1
            // 
            this.playerCard1.Location = new System.Drawing.Point(36, 75);
            this.playerCard1.Name = "playerCard1";
            this.playerCard1.Size = new System.Drawing.Size(99, 120);
            this.playerCard1.TabIndex = 5;
            this.playerCard1.TabStop = false;
            // 
            // playerCard2
            // 
            this.playerCard2.Location = new System.Drawing.Point(52, 85);
            this.playerCard2.Name = "playerCard2";
            this.playerCard2.Size = new System.Drawing.Size(99, 120);
            this.playerCard2.TabIndex = 6;
            this.playerCard2.TabStop = false;
            // 
            // playerCard3
            // 
            this.playerCard3.Location = new System.Drawing.Point(68, 95);
            this.playerCard3.Name = "playerCard3";
            this.playerCard3.Size = new System.Drawing.Size(99, 120);
            this.playerCard3.TabIndex = 7;
            this.playerCard3.TabStop = false;
            this.playerCard3.Visible = false;
            // 
            // playerCard4
            // 
            this.playerCard4.Location = new System.Drawing.Point(84, 105);
            this.playerCard4.Name = "playerCard4";
            this.playerCard4.Size = new System.Drawing.Size(99, 120);
            this.playerCard4.TabIndex = 8;
            this.playerCard4.TabStop = false;
            this.playerCard4.Visible = false;
            // 
            // dealerCard1
            // 
            this.dealerCard1.Location = new System.Drawing.Point(285, 75);
            this.dealerCard1.Name = "dealerCard1";
            this.dealerCard1.Size = new System.Drawing.Size(99, 120);
            this.dealerCard1.TabIndex = 9;
            this.dealerCard1.TabStop = false;
            // 
            // dealerCard2
            // 
            this.dealerCard2.Location = new System.Drawing.Point(301, 85);
            this.dealerCard2.Name = "dealerCard2";
            this.dealerCard2.Size = new System.Drawing.Size(99, 120);
            this.dealerCard2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.dealerCard2.TabIndex = 10;
            this.dealerCard2.TabStop = false;
            // 
            // dealerCard3
            // 
            this.dealerCard3.Location = new System.Drawing.Point(317, 95);
            this.dealerCard3.Name = "dealerCard3";
            this.dealerCard3.Size = new System.Drawing.Size(99, 120);
            this.dealerCard3.TabIndex = 11;
            this.dealerCard3.TabStop = false;
            this.dealerCard3.Visible = false;
            // 
            // dealerCard4
            // 
            this.dealerCard4.Location = new System.Drawing.Point(333, 105);
            this.dealerCard4.Name = "dealerCard4";
            this.dealerCard4.Size = new System.Drawing.Size(99, 120);
            this.dealerCard4.TabIndex = 12;
            this.dealerCard4.TabStop = false;
            this.dealerCard4.Visible = false;
            // 
            // dealerCard5
            // 
            this.dealerCard5.Location = new System.Drawing.Point(349, 115);
            this.dealerCard5.Name = "dealerCard5";
            this.dealerCard5.Size = new System.Drawing.Size(99, 120);
            this.dealerCard5.TabIndex = 14;
            this.dealerCard5.TabStop = false;
            this.dealerCard5.Visible = false;
            // 
            // playerCard5
            // 
            this.playerCard5.Location = new System.Drawing.Point(100, 115);
            this.playerCard5.Name = "playerCard5";
            this.playerCard5.Size = new System.Drawing.Size(99, 120);
            this.playerCard5.TabIndex = 15;
            this.playerCard5.TabStop = false;
            this.playerCard5.Visible = false;
            // 
            // playerTotal
            // 
            this.playerTotal.AutoSize = true;
            this.playerTotal.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.playerTotal.ForeColor = System.Drawing.Color.Gold;
            this.playerTotal.Location = new System.Drawing.Point(123, 34);
            this.playerTotal.Name = "playerTotal";
            this.playerTotal.Size = new System.Drawing.Size(40, 17);
            this.playerTotal.TabIndex = 16;
            this.playerTotal.Text = "total";
            this.playerTotal.Visible = false;
            // 
            // playerSlash
            // 
            this.playerSlash.AutoSize = true;
            this.playerSlash.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.playerSlash.ForeColor = System.Drawing.Color.Gold;
            this.playerSlash.Location = new System.Drawing.Point(158, 34);
            this.playerSlash.Name = "playerSlash";
            this.playerSlash.Size = new System.Drawing.Size(13, 17);
            this.playerSlash.TabIndex = 17;
            this.playerSlash.Text = "/";
            this.playerSlash.Visible = false;
            // 
            // playerTotal2
            // 
            this.playerTotal2.AutoSize = true;
            this.playerTotal2.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.playerTotal2.ForeColor = System.Drawing.Color.Gold;
            this.playerTotal2.Location = new System.Drawing.Point(167, 34);
            this.playerTotal2.Name = "playerTotal2";
            this.playerTotal2.Size = new System.Drawing.Size(49, 17);
            this.playerTotal2.TabIndex = 18;
            this.playerTotal2.Text = "total2";
            this.playerTotal2.Visible = false;
            // 
            // dealerTotal
            // 
            this.dealerTotal.AutoSize = true;
            this.dealerTotal.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dealerTotal.ForeColor = System.Drawing.Color.Gold;
            this.dealerTotal.Location = new System.Drawing.Point(367, 34);
            this.dealerTotal.Name = "dealerTotal";
            this.dealerTotal.Size = new System.Drawing.Size(40, 17);
            this.dealerTotal.TabIndex = 19;
            this.dealerTotal.Text = "total";
            this.dealerTotal.Visible = false;
            // 
            // dealerSlash
            // 
            this.dealerSlash.AutoSize = true;
            this.dealerSlash.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dealerSlash.ForeColor = System.Drawing.Color.Gold;
            this.dealerSlash.Location = new System.Drawing.Point(404, 34);
            this.dealerSlash.Name = "dealerSlash";
            this.dealerSlash.Size = new System.Drawing.Size(13, 17);
            this.dealerSlash.TabIndex = 20;
            this.dealerSlash.Text = "/";
            this.dealerSlash.Visible = false;
            // 
            // dealerTotal2
            // 
            this.dealerTotal2.AutoSize = true;
            this.dealerTotal2.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dealerTotal2.ForeColor = System.Drawing.Color.Gold;
            this.dealerTotal2.Location = new System.Drawing.Point(417, 34);
            this.dealerTotal2.Name = "dealerTotal2";
            this.dealerTotal2.Size = new System.Drawing.Size(49, 17);
            this.dealerTotal2.TabIndex = 21;
            this.dealerTotal2.Text = "total2";
            this.dealerTotal2.Visible = false;
            // 
            // playerBust
            // 
            this.playerBust.AutoSize = true;
            this.playerBust.BackColor = System.Drawing.Color.ForestGreen;
            this.playerBust.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.playerBust.ForeColor = System.Drawing.Color.Gold;
            this.playerBust.Location = new System.Drawing.Point(79, 238);
            this.playerBust.Name = "playerBust";
            this.playerBust.Size = new System.Drawing.Size(58, 20);
            this.playerBust.TabIndex = 22;
            this.playerBust.Text = "BUST";
            this.playerBust.Visible = false;
            // 
            // playerBlackjack
            // 
            this.playerBlackjack.AutoSize = true;
            this.playerBlackjack.BackColor = System.Drawing.Color.ForestGreen;
            this.playerBlackjack.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.playerBlackjack.ForeColor = System.Drawing.Color.Gold;
            this.playerBlackjack.Location = new System.Drawing.Point(50, 238);
            this.playerBlackjack.Name = "playerBlackjack";
            this.playerBlackjack.Size = new System.Drawing.Size(117, 20);
            this.playerBlackjack.TabIndex = 23;
            this.playerBlackjack.Text = "BLACKJACK";
            this.playerBlackjack.Visible = false;
            // 
            // dealerBust
            // 
            this.dealerBust.AutoSize = true;
            this.dealerBust.BackColor = System.Drawing.Color.ForestGreen;
            this.dealerBust.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dealerBust.ForeColor = System.Drawing.Color.Gold;
            this.dealerBust.Location = new System.Drawing.Point(329, 238);
            this.dealerBust.Name = "dealerBust";
            this.dealerBust.Size = new System.Drawing.Size(58, 20);
            this.dealerBust.TabIndex = 24;
            this.dealerBust.Text = "BUST";
            this.dealerBust.Visible = false;
            // 
            // dealerBlackjack
            // 
            this.dealerBlackjack.AutoSize = true;
            this.dealerBlackjack.BackColor = System.Drawing.Color.ForestGreen;
            this.dealerBlackjack.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dealerBlackjack.ForeColor = System.Drawing.Color.Gold;
            this.dealerBlackjack.Location = new System.Drawing.Point(300, 238);
            this.dealerBlackjack.Name = "dealerBlackjack";
            this.dealerBlackjack.Size = new System.Drawing.Size(117, 20);
            this.dealerBlackjack.TabIndex = 25;
            this.dealerBlackjack.Text = "BLACKJACK";
            this.dealerBlackjack.Visible = false;
            // 
            // winLabel
            // 
            this.winLabel.AutoSize = true;
            this.winLabel.BackColor = System.Drawing.Color.ForestGreen;
            this.winLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 30F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.winLabel.ForeColor = System.Drawing.Color.Red;
            this.winLabel.Location = new System.Drawing.Point(160, 115);
            this.winLabel.Name = "winLabel";
            this.winLabel.Size = new System.Drawing.Size(125, 58);
            this.winLabel.TabIndex = 26;
            this.winLabel.Text = "WIN";
            this.winLabel.Visible = false;
            // 
            // pushLabel
            // 
            this.pushLabel.AutoSize = true;
            this.pushLabel.BackColor = System.Drawing.Color.ForestGreen;
            this.pushLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.pushLabel.ForeColor = System.Drawing.Color.Gold;
            this.pushLabel.Location = new System.Drawing.Point(77, 238);
            this.pushLabel.Name = "pushLabel";
            this.pushLabel.Size = new System.Drawing.Size(60, 20);
            this.pushLabel.TabIndex = 27;
            this.pushLabel.Text = "PUSH";
            this.pushLabel.Visible = false;
            // 
            // gameOverLabel
            // 
            this.gameOverLabel.AutoSize = true;
            this.gameOverLabel.BackColor = System.Drawing.Color.ForestGreen;
            this.gameOverLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 30F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gameOverLabel.ForeColor = System.Drawing.Color.Red;
            this.gameOverLabel.Location = new System.Drawing.Point(58, 115);
            this.gameOverLabel.Name = "gameOverLabel";
            this.gameOverLabel.Size = new System.Drawing.Size(335, 58);
            this.gameOverLabel.TabIndex = 28;
            this.gameOverLabel.Text = "GAME OVER";
            // 
            // helpBtn
            // 
            this.helpBtn.BackColor = System.Drawing.Color.Gold;
            this.helpBtn.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.helpBtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.helpBtn.Location = new System.Drawing.Point(5, 367);
            this.helpBtn.Name = "helpBtn";
            this.helpBtn.Size = new System.Drawing.Size(86, 28);
            this.helpBtn.TabIndex = 29;
            this.helpBtn.Text = "HELP";
            this.helpBtn.UseVisualStyleBackColor = false;
            this.helpBtn.Click += new System.EventHandler(this.helpBtn_Click);
            // 
            // winLoseTimer
            // 
            this.winLoseTimer.Enabled = true;
            this.winLoseTimer.Interval = 500;
            this.winLoseTimer.Tick += new System.EventHandler(this.winLoseTimer_Tick);
            // 
            // creditLabel
            // 
            this.creditLabel.AutoSize = true;
            this.creditLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.creditLabel.ForeColor = System.Drawing.Color.Gold;
            this.creditLabel.Location = new System.Drawing.Point(318, 323);
            this.creditLabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.creditLabel.Name = "creditLabel";
            this.creditLabel.Size = new System.Drawing.Size(164, 29);
            this.creditLabel.TabIndex = 80;
            this.creditLabel.Text = "CREDIT 100";
            // 
            // winAmountLabel
            // 
            this.winAmountLabel.AutoSize = true;
            this.winAmountLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.winAmountLabel.ForeColor = System.Drawing.Color.Gold;
            this.winAmountLabel.Location = new System.Drawing.Point(13, 323);
            this.winAmountLabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.winAmountLabel.Name = "winAmountLabel";
            this.winAmountLabel.Size = new System.Drawing.Size(85, 29);
            this.winAmountLabel.TabIndex = 81;
            this.winAmountLabel.Text = "WIN x";
            this.winAmountLabel.Visible = false;
            // 
            // betLabel
            // 
            this.betLabel.AutoSize = true;
            this.betLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.betLabel.ForeColor = System.Drawing.Color.White;
            this.betLabel.Location = new System.Drawing.Point(202, 292);
            this.betLabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.betLabel.Name = "betLabel";
            this.betLabel.Size = new System.Drawing.Size(61, 20);
            this.betLabel.TabIndex = 84;
            this.betLabel.Text = "BET 1";
            // 
            // betMaxButton
            // 
            this.betMaxButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.betMaxButton.Location = new System.Drawing.Point(233, 316);
            this.betMaxButton.Margin = new System.Windows.Forms.Padding(4);
            this.betMaxButton.Name = "betMaxButton";
            this.betMaxButton.Size = new System.Drawing.Size(53, 44);
            this.betMaxButton.TabIndex = 83;
            this.betMaxButton.Text = "BET MAX";
            this.betMaxButton.UseVisualStyleBackColor = true;
            this.betMaxButton.Click += new System.EventHandler(this.betMaxButton_Click);
            // 
            // betOneButton
            // 
            this.betOneButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.betOneButton.Location = new System.Drawing.Point(179, 316);
            this.betOneButton.Margin = new System.Windows.Forms.Padding(4);
            this.betOneButton.Name = "betOneButton";
            this.betOneButton.Size = new System.Drawing.Size(55, 44);
            this.betOneButton.TabIndex = 82;
            this.betOneButton.Text = "BET ONE";
            this.betOneButton.UseVisualStyleBackColor = true;
            this.betOneButton.Click += new System.EventHandler(this.betOneButton_Click);
            // 
            // Blackjack
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.ForestGreen;
            this.ClientSize = new System.Drawing.Size(490, 402);
            this.Controls.Add(this.betLabel);
            this.Controls.Add(this.betMaxButton);
            this.Controls.Add(this.betOneButton);
            this.Controls.Add(this.winAmountLabel);
            this.Controls.Add(this.creditLabel);
            this.Controls.Add(this.helpBtn);
            this.Controls.Add(this.gameOverLabel);
            this.Controls.Add(this.pushLabel);
            this.Controls.Add(this.winLabel);
            this.Controls.Add(this.dealerBlackjack);
            this.Controls.Add(this.dealerBust);
            this.Controls.Add(this.playerBlackjack);
            this.Controls.Add(this.playerBust);
            this.Controls.Add(this.dealerTotal2);
            this.Controls.Add(this.dealerSlash);
            this.Controls.Add(this.dealerTotal);
            this.Controls.Add(this.playerTotal2);
            this.Controls.Add(this.playerSlash);
            this.Controls.Add(this.playerTotal);
            this.Controls.Add(this.playerCard5);
            this.Controls.Add(this.playerCard4);
            this.Controls.Add(this.dealerCard5);
            this.Controls.Add(this.dealerCard4);
            this.Controls.Add(this.dealerCard3);
            this.Controls.Add(this.dealerCard2);
            this.Controls.Add(this.dealerCard1);
            this.Controls.Add(this.playerCard3);
            this.Controls.Add(this.playerCard2);
            this.Controls.Add(this.playerCard1);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.newGameBtn);
            this.Controls.Add(this.standBtn);
            this.Controls.Add(this.hitBtn);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Blackjack";
            this.Text = "Microsoft Casino";
            this.Load += new System.EventHandler(this.Blackjack_Load);
            ((System.ComponentModel.ISupportInitialize)(this.playerCard1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.playerCard2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.playerCard3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.playerCard4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dealerCard1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dealerCard2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dealerCard3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dealerCard4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dealerCard5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.playerCard5)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button hitBtn;
        private System.Windows.Forms.Button standBtn;
        private System.Windows.Forms.Button newGameBtn;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.PictureBox playerCard1;
        private System.Windows.Forms.PictureBox playerCard2;
        private System.Windows.Forms.PictureBox playerCard3;
        private System.Windows.Forms.PictureBox playerCard4;
        private System.Windows.Forms.PictureBox dealerCard1;
        private System.Windows.Forms.PictureBox dealerCard2;
        private System.Windows.Forms.PictureBox dealerCard3;
        private System.Windows.Forms.PictureBox dealerCard4;
        private System.Windows.Forms.PictureBox dealerCard5;
        private System.Windows.Forms.PictureBox playerCard5;
        private System.Windows.Forms.Label playerTotal;
        private System.Windows.Forms.Label playerSlash;
        private System.Windows.Forms.Label playerTotal2;
        private System.Windows.Forms.Label dealerTotal;
        private System.Windows.Forms.Label dealerSlash;
        private System.Windows.Forms.Label dealerTotal2;
        private System.Windows.Forms.Label playerBust;
        private System.Windows.Forms.Label playerBlackjack;
        private System.Windows.Forms.Label dealerBust;
        private System.Windows.Forms.Label dealerBlackjack;
        private System.Windows.Forms.Label winLabel;
        private System.Windows.Forms.Label pushLabel;
        private System.Windows.Forms.Label gameOverLabel;
        private System.Windows.Forms.Button helpBtn;
        private System.Windows.Forms.Timer winLoseTimer;
        private System.Windows.Forms.Label creditLabel;
        private System.Windows.Forms.Label winAmountLabel;
        private System.Windows.Forms.Label betLabel;
        private System.Windows.Forms.Button betMaxButton;
        private System.Windows.Forms.Button betOneButton;
    }
}