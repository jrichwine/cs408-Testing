﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Game
{
    public partial class Blackjack : Form
    {
        bool win = false;
        const int CREDITS = 100;
        int numCredits = CREDITS;
        int betAmount = 1;

        public Blackjack()
        {
            InitializeComponent();
        }

        private int getPlayerTotal()
        {
            return BlackjackPlayer.validateHand(0);
        }
        private int getDealerTotal()
        {
            return BlackjackPlayer.validateHand(1);
        }

        private void Blackjack_Load(object sender, EventArgs e)
        {
            newGame();
            getInitialCards();
            updatePlayerTotal();
            updateInitDealerTotal();

            while (getPlayerTotal() <= 21)
            {
                playerHit();
                getHitCard(0);
                updatePlayerTotal();
            }

            winLabel.BringToFront();
            gameOverLabel.BringToFront();
            playerBlackjack.Visible = false;
            winLabel.Visible = false;
            creditLabel.Text = "CREDIT " + CREDITS;
        }

        private void hitBtn_Click(object sender, EventArgs e)
        {
            playerHit();
            getHitCard(0);
            updatePlayerTotal();

            if (getPlayerTotal() > 21)
            {
                gameOverLabel.Visible = true;
                win = false;
                winLoseTimer.Start();
                betOneButton.Enabled = true;
                betMaxButton.Enabled = true;
            }
            if (getPlayerTotal() == 21 && getDealerTotal() != 21)
            {
                winLabel.Visible = true;
                win = true;
                winLoseTimer.Start();
                betOneButton.Enabled = true;
                betMaxButton.Enabled = true;
                winAmountLabel.Visible = true;
                winAmountLabel.Text = "WIN " + (betAmount * 2);
                numCredits += betAmount * 2;
                creditLabel.Text = "CREDIT " + numCredits;
            }
            if (getPlayerTotal() == 21 && getDealerTotal() == 21)
            {
                pushLabel.Visible = true;
                win = false;
                winLoseTimer.Start();
                betOneButton.Enabled = true;
                betMaxButton.Enabled = true;
                winAmountLabel.Visible = true;
                winAmountLabel.Text = "WIN " + (betAmount);
                numCredits += betAmount;
                creditLabel.Text = "CREDIT " + numCredits;
            }

            winLabel.BringToFront();
            gameOverLabel.BringToFront();

            if (numCredits <= 0 && !win)
            {
                if (MessageBox.Show("You are out of credits. Do you want to play again?", "Video Poker", MessageBoxButtons.YesNo, MessageBoxIcon.Question)
                    == DialogResult.Yes)
                {
                    numCredits = CREDITS;
                    creditLabel.Text = "CREDIT " + numCredits;
                    return;
                }
                else
                {
                    //Application.Exit();
                    this.Close();
                }
            }

            if (betAmount > numCredits)
            {
                betAmount = numCredits;
                betLabel.Text = "BET " + betAmount;
            }
        }

        private void standBtn_Click(object sender, EventArgs e)
        {
            dealerHit();
            getDealerHit();
            hitBtn.Enabled = false;
            standBtn.Enabled = false;
            newGameBtn.Enabled = true;

            if (getDealerTotal() > 21)
            {
                winLabel.Visible = true;
                win = true;
                winAmountLabel.Visible = true;
                winAmountLabel.Text = "WIN " + (betAmount * 2);
                numCredits += betAmount * 2;
                creditLabel.Text = "CREDIT " + numCredits;
            }
            else if (getPlayerTotal() > getDealerTotal())
            {
                winLabel.Visible = true;
                win = true;
                winAmountLabel.Visible = true;
                winAmountLabel.Text = "WIN " + (betAmount * 2);
                numCredits += betAmount * 2;
                creditLabel.Text = "CREDIT " + numCredits;
            }
            else if (getPlayerTotal() == getDealerTotal())
            {
                pushLabel.Visible = true;
                gameOverLabel.Visible = true;
                win = false;
                winAmountLabel.Visible = true;
                winAmountLabel.Text = "WIN " + (betAmount);
                numCredits += betAmount;
                creditLabel.Text = "CREDIT " + numCredits;
            }
            else if (getPlayerTotal() < getDealerTotal())
            {
                gameOverLabel.Visible = true;
                win = false;
            }

            winLabel.BringToFront();
            gameOverLabel.BringToFront();

            winLoseTimer.Start();

            betOneButton.Enabled = true;
            betMaxButton.Enabled = true;

            if (numCredits <= 0 && !win)
            {
                if (MessageBox.Show("You are out of credits. Do you want to play again?", "Video Poker", MessageBoxButtons.YesNo, MessageBoxIcon.Question)
                    == DialogResult.Yes)
                {
                    numCredits = CREDITS;
                    creditLabel.Text = "CREDIT " + numCredits;
                    return;
                }
                else
                {
                    //Application.Exit();
                    this.Close();
                }
            }

            if (betAmount > numCredits)
            {
                betAmount = numCredits;
                betLabel.Text = "BET " + betAmount;
            }
        }

        private void newGameBtn_Click(object sender, EventArgs e)
        {
            winLoseTimer.Stop();

            winAmountLabel.Visible = false;

            newGameBtn.Enabled = false;
            hitBtn.Enabled = true;
            standBtn.Enabled = true;

            betOneButton.Enabled = false;
            betMaxButton.Enabled = false;

            playerBlackjack.Visible = false;
            playerBust.Visible = false;
            playerSlash.Visible = false;
            playerTotal2.Visible = false;
            playerCard3.Visible = false;
            playerCard4.Visible = false;
            playerCard5.Visible = false;

            dealerBlackjack.Visible = false;
            dealerBust.Visible = false;
            dealerSlash.Visible = false;
            dealerTotal2.Visible = false;
            dealerCard3.Visible = false;
            dealerCard4.Visible = false;
            dealerCard5.Visible = false;

            gameOverLabel.Visible = false;
            winLabel.Visible = false;
            pushLabel.Visible = false;

            numCredits -= betAmount;
            creditLabel.Text = "CREDIT " + numCredits;

            newGame();
            getInitialCards();
            updatePlayerTotal();
            updateInitDealerTotal();
        }

        private void winLoseTimer_Tick(object sender, EventArgs e)
        {
            if (!win)
            {
                winLabel.Visible = false;
                if (gameOverLabel.Visible == false)
                {
                    gameOverLabel.Visible = true;
                }
                else
                {
                    gameOverLabel.Visible = false;
                }
            }
            else
            {
                gameOverLabel.Visible = false;
                if (winLabel.Visible == false)
                {
                    winLabel.Visible = true;
                }
                else
                {
                    winLabel.Visible = false;
                }
            }
        }

        private void betOneButton_Click(object sender, EventArgs e)
        {
            if (betAmount == 10)
            {
                betAmount = -1;
                betLabel.Text = "BET " + betAmount;
            }
            else
            {
                betAmount++;
                betLabel.Text = "BET " + betAmount;
            } 
        }

        private void betMaxButton_Click(object sender, EventArgs e)
        {
            betAmount = 5;
            betLabel.Text = "BET " + betAmount;
        }

        private void helpBtn_Click(object sender, EventArgs e)
        {
            BlackjackHelpForm b = new BlackjackHelpForm();
            b.Show();
        }
    }
}