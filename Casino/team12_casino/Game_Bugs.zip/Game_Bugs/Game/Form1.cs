﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Game
{
    public partial class Form1 : Form
    {
        const int CREDITS = 100;
        int counter = 0;
        int betAmount = 1;
        int numCredits = CREDITS;
        bool win = false;

        public Form1()
        {
            InitializeComponent();
            getCards();
            creditLabel.Text = "CREDIT " + numCredits;
        }

        private void dealButton_Click(object sender, EventArgs e)
        {
            counter++;
            if (counter % 2 == 0)
            {
                dealButton.Visible = false;
                newGameButton.Visible = true;
            }
            getNewCards();
            checkWin();

            card1.Enabled = false;
            card2.Enabled = false;
            card3.Enabled = false;
            card4.Enabled = false;
            card5.Enabled = false;
            betOneButton.Enabled = true;
            betMaxButton.Enabled = true;

            winLoseTimer.Start();
        }

        private void card1_Click(object sender, EventArgs e)
        {
            hold1.Visible = true;
        }

        private void card2_Click(object sender, EventArgs e)
        {
            hold2.Visible = true;
        }

        private void card3_Click(object sender, EventArgs e)
        {
            hold3.Visible = true;
        }

        private void card4_Click(object sender, EventArgs e)
        {
            hold4.Visible = true;
        }

        private void card5_Click(object sender, EventArgs e)
        {
            hold5.Visible = true;
        }

        private void newGameButton_Click(object sender, EventArgs e)
        {
            counter++;
            newGameButton.Visible = false;
            dealButton.Visible = true;

            newGame();
            getCards();

            hold1.Visible = false;
            hold2.Visible = false;
            hold3.Visible = false;
            hold4.Visible = false;
            hold5.Visible = false;
            setHold(1, false);
            setHold(2, false);
            setHold(3, false);
            setHold(4, false);
            setHold(5, false);

            winLabel.Visible = false;
            //gameOverLabel.Visible = false;
            winAmountLabel.Visible = false;

            royalFlushLabel.ForeColor = System.Drawing.Color.Gold;
            straightFlushLabel.ForeColor = System.Drawing.Color.Gold;
            fourKindLabel.ForeColor = System.Drawing.Color.Gold;
            fullHouselabel.ForeColor = System.Drawing.Color.Gold;
            flushLabel.ForeColor = System.Drawing.Color.Gold;
            straightLabel.ForeColor = System.Drawing.Color.Gold;
            threeKindLabel.ForeColor = System.Drawing.Color.Gold;
            twoPairLabel.ForeColor = System.Drawing.Color.Gold;
            jacksBetterLabel.ForeColor = System.Drawing.Color.Gold;

            rf1Label.ForeColor = System.Drawing.Color.Gold;
            rf2Label.ForeColor = System.Drawing.Color.Gold;
            rf3Label.ForeColor = System.Drawing.Color.Gold;
            rf4Label.ForeColor = System.Drawing.Color.Gold;
            rf5Label.ForeColor = System.Drawing.Color.Gold;

            sf1Label.ForeColor = System.Drawing.Color.Gold;
            sf2Label.ForeColor = System.Drawing.Color.Gold;
            sf3Label.ForeColor = System.Drawing.Color.Gold;
            sf4Label.ForeColor = System.Drawing.Color.Gold;
            sf5Label.ForeColor = System.Drawing.Color.Gold;

            fk1Label.ForeColor = System.Drawing.Color.Gold;
            fk2Label.ForeColor = System.Drawing.Color.Gold;
            fk3Label.ForeColor = System.Drawing.Color.Gold;
            fk4Label.ForeColor = System.Drawing.Color.Gold;
            fk5Label.ForeColor = System.Drawing.Color.Gold;

            fh1Label.ForeColor = System.Drawing.Color.Gold;
            fh2Label.ForeColor = System.Drawing.Color.Gold;
            fh3Label.ForeColor = System.Drawing.Color.Gold;
            fh4Label.ForeColor = System.Drawing.Color.Gold;
            fh5Label.ForeColor = System.Drawing.Color.Gold;

            f1Label.ForeColor = System.Drawing.Color.Gold;
            f2Label.ForeColor = System.Drawing.Color.Gold;
            f3Label.ForeColor = System.Drawing.Color.Gold;
            f4Label.ForeColor = System.Drawing.Color.Gold;
            f5Label.ForeColor = System.Drawing.Color.Gold;

            s1Label.ForeColor = System.Drawing.Color.Gold;
            s2Label.ForeColor = System.Drawing.Color.Gold;
            s3Label.ForeColor = System.Drawing.Color.Gold;
            s4Label.ForeColor = System.Drawing.Color.Gold;
            s5Label.ForeColor = System.Drawing.Color.Gold;

            tk1Label.ForeColor = System.Drawing.Color.Gold;
            tk2Label.ForeColor = System.Drawing.Color.Gold;
            tk3Label.ForeColor = System.Drawing.Color.Gold;
            tk4Label.ForeColor = System.Drawing.Color.Gold;
            tk5Label.ForeColor = System.Drawing.Color.Gold;

            tp1Label.ForeColor = System.Drawing.Color.Gold;
            tp2Label.ForeColor = System.Drawing.Color.Gold;
            tp3Label.ForeColor = System.Drawing.Color.Gold;
            tp4Label.ForeColor = System.Drawing.Color.Gold;
            tp5Label.ForeColor = System.Drawing.Color.Gold;

            jb1Label.ForeColor = System.Drawing.Color.Gold;
            jb2Label.ForeColor = System.Drawing.Color.Gold;
            jb3Label.ForeColor = System.Drawing.Color.Gold;
            jb4Label.ForeColor = System.Drawing.Color.Gold;
            jb5Label.ForeColor = System.Drawing.Color.Gold;

            numCredits -= betAmount;
            creditLabel.Text = "CREDIT " + numCredits;

            card1.Enabled = true;
            card2.Enabled = true;
            card3.Enabled = true;
            card4.Enabled = true;
            card5.Enabled = true;
            betOneButton.Enabled = false;
            betMaxButton.Enabled = false;

            //winLoseTimer.Stop();
        }

        private void betOneButton_Click(object sender, EventArgs e)
        {
            betAmount++;
            betLabel.Text = "BET " + betAmount;
        }

        private void betMaxButton_Click(object sender, EventArgs e)
        {
            betAmount += 5;
            betLabel.Text = "BET " + betAmount;
        }

        private void winLoseTimer_Tick(object sender, EventArgs e)
        {
            if (!win)
            {
                winLabel.Visible = false;
                if (gameOverLabel.Visible == false)
                {
                    gameOverLabel.Visible = true;
                }
                else
                {
                    gameOverLabel.Visible = false;
                } 
            }
            else
            {
                gameOverLabel.Visible = false;
                if (winLabel.Visible == false)
                {
                    winLabel.Visible = true;
                }
                else
                {
                    winLabel.Visible = false;
                }
            }
        }

        private void helpButton_Click(object sender, EventArgs e)
        {
            HelpForm help = new HelpForm();
            help.Show();
            numCredits = 0;
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }
    }
}
